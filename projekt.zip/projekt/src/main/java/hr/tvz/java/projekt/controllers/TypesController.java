package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.ChangeType;
import hr.tvz.java.projekt.entiteti.EggGroup;
import hr.tvz.java.projekt.files.TypeReader;
import hr.tvz.java.projekt.entiteti.Type;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TypesController implements ControllerPokedex {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField nameTextField;
    @FXML
    private TableView<Type> typeTableView;
    @FXML
    private TableColumn<Type, String> nameTableColumn;
    @FXML
    private Button remove;
    private List<Type> typeList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            typeList = BazaPodataka.getTypeBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        if (LoginController.currentRole.id().equals(1L))
            remove.setVisible(true);

        nameTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        typeTableView.setItems(FXCollections.observableList(typeList));
        logger.info("Type ekran inicijaliziran.");
    }
    @FXML
    public void search() {
        List<Type> sortedList = typeList;
        if (!nameTextField.getText().isBlank()) {
            sortedList = sortedList
                    .stream()
                    .filter(type -> type.getName().contains(nameTextField.getText().trim()))
                    .toList();
            logger.info("Izvršena pretraga type s imenom: " + nameTextField.getText().trim());
        } else
            logger.info("Izvršena pretraga type.");
        typeTableView.setItems(FXCollections.observableList(sortedList));
    }

    @FXML
    public void add() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("dodavanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Type newType = BazaPodataka.addType(nameTextField.getText().trim());
                        typeList = BazaPodataka.getTypeBy(null);
                        typeTableView.setItems(FXCollections.observableList(typeList));
                        String message = "Dodan novi type imena: " + nameTextField.getText().trim();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                        Change<Type> change = new Change<>(newType, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    } catch (SameNameException e) {
                        QuickDialog.dialogWarning(e.getMessage());
                    }
                }
            }
        }
    }

    @FXML
    public void remove() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("brisanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Optional<Type> optionalType = BazaPodataka.removeType(nameTextField.getText().trim());
                        if (optionalType.isPresent()) {
                            typeList = BazaPodataka.getTypeBy(null);
                            typeTableView.setItems(FXCollections.observableList(typeList));
                            String message = "Izbrisan type imena: " + optionalType.get().getName();
                            logger.info(message);
                            QuickDialog.dialogInfo(message);
                            Change<Type> change = new Change<>(optionalType.get(), LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                            change.addToDat();
                        }
                        else {
                            logger.warn("Pokušaj brisanja type s imenom: " + nameTextField.getText().trim());
                            QuickDialog.dialogWarning("Ne postoji type s imenom " + nameTextField.getText().trim());
                        }
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }
        }
    }
}
