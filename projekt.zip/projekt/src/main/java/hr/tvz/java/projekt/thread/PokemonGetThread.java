package hr.tvz.java.projekt.thread;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class PokemonGetThread implements Runnable{
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    private final Pokemon pokemonInput;
    private final Connection connection;

    public PokemonGetThread(Pokemon pokemonInput, Connection connection) {
        this.pokemonInput = pokemonInput;
        this.connection = connection;
    }

    @Override
    public void run() {
        try {
            Set<Ability> abilitySet = new HashSet<>();
            Set<EggGroup> eggGroupSet = new HashSet<>();
            Set<Type> typeSet = new HashSet<>();
            Map<LearnableMovesType, Set<Move>> moveMap = new HashMap<>();
            Arrays.stream(LearnableMovesType.values()).forEach(learnableMoveType -> moveMap.put(learnableMoveType, new HashSet<>()));

            ResultSet resultSetAbility = connection.createStatement().executeQuery(
                    "SELECT * FROM POKEDEX_ABILITY WHERE POKEMON_ID = " + pokemonInput.getId()
            );

            boolean postoji = false;
            List<Ability> abilityList = BazaPodataka.getAbilityBy(null);
            while (resultSetAbility.next()) {
                Long abilityId = resultSetAbility.getLong("ability_id");
                Ability newAbility = abilityList.stream().filter(ability -> ability.getId().equals(abilityId)).findFirst().get();
                if (resultSetAbility.getBoolean("hidden"))
                    newAbility.setHidden(true);
                abilitySet.add(newAbility);

                if (pokemonInput.getAllAbilities().isEmpty())
                    postoji = true;
                else {
                    for (Ability abilityInput : pokemonInput.getAllAbilities()) {
                        if (abilityInput.getId().equals(abilityId)) {
                            if (abilityInput.getHidden()) {
                                if (resultSetAbility.getBoolean("hidden")) {
                                    postoji = true;
                                    break;
                                }
                            } else {
                                postoji = true;
                                break;
                            }
                        }
                    }
                }
            }
            if (!postoji) return;

            ResultSet resultSetEggGroup = connection.createStatement().executeQuery(
                    "SELECT * FROM POKEDEX_EGG_GROUP WHERE POKEMON_ID = " + pokemonInput.getId()
            );

            postoji = false;
            List<EggGroup> eggGroupList = BazaPodataka.getEggGroupBy(null);
            while (resultSetEggGroup.next()) {
                Long eggGroupId = resultSetEggGroup.getLong("egg_group_id");
                EggGroup newEggGroup = eggGroupList.stream().filter(eggGroup -> eggGroup.getId().equals(eggGroupId)).findFirst().get();
                eggGroupSet.add(newEggGroup);

                if (pokemonInput.getEggGroups().isEmpty())
                    postoji = true;
                else {
                    for (EggGroup eggGroupInput : pokemonInput.getEggGroups()) {
                        if (eggGroupInput.getId().equals(eggGroupId)) {
                            postoji = true;
                            break;
                        }
                    }
                }
            }
            if (!postoji) return;

            ResultSet resultSetType = connection.createStatement().executeQuery(
                    "SELECT * FROM POKEDEX_TYPE WHERE POKEMON_ID = " + pokemonInput.getId()
            );

            postoji = false;
            List<Type> typeList = BazaPodataka.getTypeBy(null);
            while (resultSetType.next()) {
                Long typeId = resultSetType.getLong("type_id");
                Type newType = typeList.stream().filter(type -> type.getId().equals(typeId)).findFirst().get();
                typeSet.add(newType);

                if (pokemonInput.getType().isEmpty())
                    postoji = true;
                else {
                    for (Type typeInput : pokemonInput.getType()) {
                        if (typeInput.getId().equals(typeId)) {
                            postoji = true;
                            break;
                        }
                    }
                }
            }
            if (!postoji) return;

            ResultSet resultSetMove = connection.createStatement().executeQuery(
                    "SELECT * FROM POKEDEX_MOVES WHERE POKEMON_ID = " + pokemonInput.getId()
            );

            postoji = false;
            List<Move> moveList = BazaPodataka.getMoveBy(null);
            while (resultSetMove.next()) {
                Long moveId = resultSetMove.getLong("move_id");
                Integer learnableMoveTypeId = resultSetMove.getInt("learnable_move_type");
                Optional<LearnableMovesType> learnableMovesTypeOptional = Arrays.stream(LearnableMovesType.values())
                        .filter(m -> m.getId().equals(learnableMoveTypeId))
                        .findFirst();

                Set<Move> moveSet = moveMap.get(learnableMovesTypeOptional.get());
                moveSet.add(moveList.stream().filter(move -> move.getId().equals(moveId)).findFirst().get());
                moveMap.put(learnableMovesTypeOptional.get(), moveSet);

                if (pokemonInput.getLearnableMoves().isEmpty())
                    postoji = true;
                else {
                    for (LearnableMovesType learnableMovesType : LearnableMovesType.values()) {
                        if (pokemonInput.getLearnableMoves().containsKey(learnableMovesType) && moveMap.containsKey(learnableMovesType)) {
                            for (Move moveInput : pokemonInput.getLearnableMoves().get(learnableMovesType)) {
                                for (Move move : moveMap.get(learnableMovesType)) {
                                    if (move.getId().equals(moveInput.getId())) {
                                        postoji = true;
                                        break;
                                    }
                                }
                                if (postoji) break;
                            }
                        }
                        if (postoji) break;
                    }
                }
            }
            if (!postoji) return;

            Pokemon newPokemon = new Pokemon.Builder(pokemonInput.getId(), pokemonInput.getName())
                    .setPokedexNumber(pokemonInput.getPokedexNumber())
                    .setType(typeSet)
                    .setLearnableMoves(moveMap)
                    .setAllAbilities(abilitySet)
                    .setBaseStats(pokemonInput.getBaseStats())
                    .setEggGroups(eggGroupSet)
                    .build();
            BazaPodataka.pokemonList.add(newPokemon);
        } catch (SQLException | BazaPodatakaException e) {
            logger.error(e.getMessage(), e);
        }
    }
}
