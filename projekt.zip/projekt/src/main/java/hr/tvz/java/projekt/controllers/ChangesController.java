package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.files.ChangeReader;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class ChangesController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TableView<Change<Entitet>> changeTableView;
    @FXML
    private TableColumn<Change<Entitet>, String> dataTypeTableColumn;
    @FXML
    private TableColumn<Change<Entitet>, String> dataTableColumn;
    @FXML
    private TableColumn<Change<Entitet>, String> roleTableColumn;
    @FXML
    private TableColumn<Change<Entitet>, String> dateAndTimeTableColumn;
    @FXML
    private TableColumn<Change<Entitet>, String> changeTypeTableColumn;

    @FXML
    private void initialize() {
        List<Change<Entitet>> changeList = ChangeReader.getChanges();

        dataTypeTableColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().data() instanceof Ability)
                return new SimpleStringProperty("ability");
            else if (cellData.getValue().data() instanceof EggGroup)
                return new SimpleStringProperty("egg group");
            else if (cellData.getValue().data() instanceof Move)
                return new SimpleStringProperty("move");
            else if (cellData.getValue().data() instanceof TeamPokemon)
                return new SimpleStringProperty("pokemon team");
            else if (cellData.getValue().data() instanceof Pokemon)
                return new SimpleStringProperty("pokemon");
            else
                return new SimpleStringProperty("error");
        });
        dataTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().data().getName()));
        roleTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().role().name()));
        dateAndTimeTableColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.
                        getValue().
                        dateTime().
                        format(DateTimeFormatter.ofPattern("dd.MM.yyyy.'T'HH:mm"))));
        changeTypeTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().changeType().name()));
        changeTableView.setItems(FXCollections.observableList(changeList));
        logger.info("Changes ekran inicijaliziran.");
    }
}
