package hr.tvz.java.projekt.entiteti;

import java.io.Serializable;

public class Type extends Entitet{
    public Type(Long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return getName();
    }
}