package hr.tvz.java.projekt.entiteti;

import java.io.Serializable;

public record BaseStats (Integer hp, Integer attack, Integer defense, Integer spAttack, Integer spDefense, Integer speed) implements Serializable {
    public int baseStatsTotal() {
        return hp + attack + defense + spAttack +spDefense + speed;
    }
}