package hr.tvz.java.projekt.files;

import java.io.Serializable;

public class EndOfFile implements Serializable {
}
