package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.entiteti.BaseStats;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BaseStatsInputController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField hpTextField;
    @FXML
    private TextField attackTextField;
    @FXML
    private TextField spAttackTextField;
    @FXML
    private TextField defenseTextField;
    @FXML
    private TextField spDefenseTextField;
    @FXML
    private TextField speedTextField;
    @FXML
    private Button reset;

    @FXML
    private void initialize() {
        if (Optional.ofNullable(PokedexAddController.baseStats).isPresent()) {
            setBaseStats(PokedexAddController.baseStats);
        }
        logger.info("Base stats input ekran inicijaliziran.");
    }

    @FXML
    public void confirm() {
        List<String> errorList = new ArrayList<>();
        if (hpTextField.getText().isBlank())
            errorList.add("HP je obavezan podatak!");
        if (attackTextField.getText().isBlank())
            errorList.add("Attack je obavezan podatak!");
        if (spAttackTextField.getText().isBlank())
            errorList.add("Special attack je obavezan podatak!");
        if (defenseTextField.getText().isBlank())
            errorList.add("Defense je obavezan podatak!");
        if (spDefenseTextField.getText().isBlank())
            errorList.add("Special defense je obavezan podatak!");
        if (speedTextField.getText().isBlank())
            errorList.add("Speed je obavezan podatak!");
        if (errorList.size() == 0) {
            PokedexAddController.baseStats = new BaseStats(
                    Integer.parseInt(hpTextField.getText().trim()),
                    Integer.parseInt(attackTextField.getText().trim()),
                    Integer.parseInt(spAttackTextField.getText().trim()),
                    Integer.parseInt(defenseTextField.getText().trim()),
                    Integer.parseInt(spDefenseTextField.getText().trim()),
                    Integer.parseInt(speedTextField.getText().trim()));
            logger.info("Spremljen base stats.");
            backToPokedex();
        } else
            QuickDialog.missingInput(errorList);
    }

    @FXML
    public void backToPokedex() {
        Stage stage = (Stage) hpTextField.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void reset() {
        PokedexAddController.baseStats = null;
        hpTextField.setText("");
        attackTextField.setText("");
        spAttackTextField.setText("");
        defenseTextField.setText("");
        spDefenseTextField.setText("");
        speedTextField.setText("");
        logger.info("Brisanje base stats.");
    }

    private void setBaseStats(BaseStats baseStats) {
        hpTextField.setText(String.valueOf(baseStats.hp()));
        attackTextField.setText(String.valueOf(baseStats.attack()));
        spAttackTextField.setText(String.valueOf(baseStats.spAttack()));
        defenseTextField.setText(String.valueOf(baseStats.defense()));
        spDefenseTextField.setText(String.valueOf(baseStats.spDefense()));
        speedTextField.setText(String.valueOf(baseStats.speed()));
    }
}
