package hr.tvz.java.projekt.iznimke;

public class SameEntityAlreadyInList extends RuntimeException{
    public SameEntityAlreadyInList() {
    }

    public SameEntityAlreadyInList(String message) {
        super(message);
    }

    public SameEntityAlreadyInList(String message, Throwable cause) {
        super(message, cause);
    }

    public SameEntityAlreadyInList(Throwable cause) {
        super(cause);
    }
}
