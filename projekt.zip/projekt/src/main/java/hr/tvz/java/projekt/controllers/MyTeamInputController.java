package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import org.controlsfx.control.SearchableComboBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.*;

public class MyTeamInputController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private SearchableComboBox<Pokemon> pokemonSearchableComboBox;
    @FXML
    private SearchableComboBox<Type> teraTypeSearchableComboBox;
    @FXML
    private SearchableComboBox<Ability> abilitySearchableComboBox;
    @FXML
    private SearchableComboBox<Move> move1SearchableComboBox;
    @FXML
    private SearchableComboBox<Move> move2SearchableComboBox;
    @FXML
    private SearchableComboBox<Move> move3SearchableComboBox;
    @FXML
    private SearchableComboBox<Move> move4SearchableComboBox;
    @FXML
    private Label ability;
    @FXML
    private Label move1;
    @FXML
    private Label move2;
    @FXML
    private Label move3;
    @FXML
    private Label move4;
    @FXML
    private Button save;

    @FXML
    private void initialize() {
        try {
            List<Pokemon> pokemonList = BazaPodataka.getPokemonBy(null);
            pokemonSearchableComboBox.setItems(FXCollections.observableList(pokemonList));
            teraTypeSearchableComboBox.setItems(FXCollections.observableList(BazaPodataka.getTypeBy(null)));
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }
    }

    @FXML
    private void selectPokemon() {
        if (Optional.ofNullable(pokemonSearchableComboBox.getValue()).isPresent()) {
            Pokemon selectedPokemon = pokemonSearchableComboBox.getValue();
            List<Node> nodeList = new ArrayList<>();
            Collections.addAll(nodeList, abilitySearchableComboBox, move1SearchableComboBox, move2SearchableComboBox, move3SearchableComboBox, move4SearchableComboBox, save, ability, move1, move2, move3, move4);
            nodeList.forEach(node -> node.setVisible(true));

            abilitySearchableComboBox.setItems(FXCollections.observableList(selectedPokemon.getAllAbilities().stream().toList()));
            List<Move> moveList = new ArrayList<>();
            for (LearnableMovesType learnableMovesType : selectedPokemon.getLearnableMoves().keySet()) {
                for (Move move : selectedPokemon.getLearnableMoves().get(learnableMovesType)) {
                    if (!moveList.contains(move))
                        moveList.add(move);
                }
            }
            Set<SearchableComboBox<Move>> searchableComboBoxSet = new HashSet<>();
            Collections.addAll(searchableComboBoxSet, move1SearchableComboBox, move2SearchableComboBox, move3SearchableComboBox, move4SearchableComboBox);
            searchableComboBoxSet.forEach(moveSearchableComboBox -> moveSearchableComboBox.setItems(FXCollections.observableList(moveList)));
        }
    }

    @FXML
    private void add() {
        List<String> errorList = new ArrayList<>();
        if (Optional.ofNullable(pokemonSearchableComboBox.getValue()).isEmpty())
            errorList.add("Pokemon je obavezan podatak!");
        if (Optional.ofNullable(teraTypeSearchableComboBox.getValue()).isEmpty())
            errorList.add("Tera type je obavezan podatak!");
        if (Optional.ofNullable(abilitySearchableComboBox.getValue()).isEmpty())
            errorList.add("Ability je obavezan podatak!");
        if (Optional.ofNullable(move1SearchableComboBox.getValue()).isEmpty())
            errorList.add("Move 1 je obavezan podatak!");
        if (Optional.ofNullable(move2SearchableComboBox.getValue()).isEmpty())
            errorList.add("Move 2 je obavezan podatak!");
        if (Optional.ofNullable(move3SearchableComboBox.getValue()).isEmpty())
            errorList.add("Move 3 je obavezan podatak!");
        if (Optional.ofNullable(move4SearchableComboBox.getValue()).isEmpty())
            errorList.add("Move 4 je obavezan podatak!");
        if (errorList.size() == 0) {
            Alert alert = QuickDialog.potvrda("dodavanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)) {
                    try {
                        Set<Move> moveSet = new HashSet<>();
                        Collections.addAll(moveSet, move1SearchableComboBox.getValue(), move2SearchableComboBox.getValue(), move3SearchableComboBox.getValue(), move4SearchableComboBox.getValue());

                        TeamPokemon teamPokemonInput = new TeamPokemon(null, pokemonSearchableComboBox.getValue(), moveSet, abilitySearchableComboBox.getValue(), teraTypeSearchableComboBox.getValue());
                        TeamPokemon newTeamPokemon = BazaPodataka.addTeamPokemon(teamPokemonInput);
                        String message = "Dodan novi pokemon u tim imena: " + teamPokemonInput.getName();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                        Change<TeamPokemon> change = new Change<>(newTeamPokemon, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }
        } else
            QuickDialog.missingInput(errorList);
    }
}
