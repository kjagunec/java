package hr.tvz.java.projekt.main;

import java.io.File;
import java.nio.file.Path;

public class Main {

    public static void main(String[] args) {
        File destination = new File(LoginScreen.class.getResource("login.fxml").getFile()).getParentFile();
        System.out.println(destination);
    }


}
