package hr.tvz.java.projekt.main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class LoginScreen extends Application {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    private static Stage mainStage;

    @Override
    public void start(Stage stage) throws IOException {
        mainStage = stage;
        logger.info("APLIKACIJA JE POKRENUTA.");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        scene.getStylesheets().add(getClass().getResource("stylesheets.css").toString());
        logger.info("Login ekran se učitava.");
        stage.setTitle("Pokedex");
        stage.getIcons().add(new Image(getClass().getResource("logo.jpg").toString()));
        stage.setScene(scene);
        stage.show();
        logger.info("Login ekran je pokazan.");
    }
    public static void main(String[] args) {
        launch();
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    public static void setMainPage(Parent root) {
        Scene scene = new Scene(root,600,400);
        scene.getStylesheets().add(LoginScreen.class.getResource("stylesheets.css").toString());
        mainStage.setScene(scene);
        mainStage.show();
    }
}