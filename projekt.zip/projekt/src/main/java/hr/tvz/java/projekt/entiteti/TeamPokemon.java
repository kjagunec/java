package hr.tvz.java.projekt.entiteti;

import java.util.Map;
import java.util.Set;

public class TeamPokemon extends Entitet{
    private Pokemon pokemon;
    private Set<Move> moves;
    private Ability ability;
    private Type teraType;

    public TeamPokemon(Long id, Pokemon pokemon, Set<Move> moves, Ability ability, Type teraType) {
        super(id, pokemon.getName());
        this.pokemon = pokemon;
        this.moves = moves;
        this.ability = ability;
        this.teraType = teraType;
    }
    public TeamPokemon(Long id, String name) {
        super(id, name);
    }

    public Pokemon getPokemon() {
        return pokemon;
    }

    public void setPokemon(Pokemon pokemon) {
        this.pokemon = pokemon;
    }

    public Set<Move> getMoves() {
        return moves;
    }

    public void setMoves(Set<Move> moves) {
        this.moves = moves;
    }

    public Ability getAbility() {
        return ability;
    }

    public void setAbility(Ability ability) {
        this.ability = ability;
    }

    public Type getTeraType() {
        return teraType;
    }

    public void setTeraType(Type teraType) {
        this.teraType = teraType;
    }
}
    /*CREATE TABLE TEAM_POKEMON(
        id INT NOT NULL,
        pokemon_id LONG NOT NULL,
        ability_id LONG NOT NULL,
        tery_type_id LONG NOT NULL,
        PRIMARY KEY(id),
        FOREIGN KEY(pokemon_id) REFERENCES POKEDEX(id),
        FOREIGN KEY(ability_id) REFERENCES ABILITY(id),
        FOREIGN KEY(tery_type_id) REFERENCES TYPE(id));
      CREATE TABLE TEAM_POKEMON_MOVES(
        team_pokemon_id INT NOT NULL,
        move_id LONG NOT NULL,
        PRIMARY KEY(team_pokemon_id, move_id),
        FOREIGN KEY(team_pokemon_id) REFERENCES TEAM_POKEMON(id),
        FOREIGN KEY(move_id) REFERENCES MOVE(id));
     */