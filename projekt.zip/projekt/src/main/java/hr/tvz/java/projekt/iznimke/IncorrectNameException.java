package hr.tvz.java.projekt.iznimke;

public class IncorrectNameException extends Exception{
    public IncorrectNameException() {
    }

    public IncorrectNameException(String message) {
        super(message);
    }

    public IncorrectNameException(String message, Throwable cause) {
        super(message, cause);
    }

    public IncorrectNameException(Throwable cause) {
        super(cause);
    }
}
