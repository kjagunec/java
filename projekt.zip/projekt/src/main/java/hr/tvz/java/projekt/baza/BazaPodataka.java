package hr.tvz.java.projekt.baza;

import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.files.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.sort.TypeSorter;
import hr.tvz.java.projekt.thread.PokemonGetThread;
import hr.tvz.java.projekt.thread.TeamPokemonGetThread;
import hr.tvz.java.projekt.util.QuickDialog;
import hr.tvz.java.projekt.util.ThreadInputData;
import javafx.scene.control.Alert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class BazaPodataka {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    private static final String DATABASE_FILE = "dat/database.properties";
    private static final String message = "Pogreška pri radu s bazom podataka!";
    public static List<Pokemon> pokemonList = Collections.synchronizedList(new ArrayList<>());
    public static List<TeamPokemon> teamPokemonList = Collections.synchronizedList(new ArrayList<>());
    private static Connection connectToBase() throws SQLException {
        Properties properties = new Properties();
        Optional<String> databaseUrl = Optional.empty(), username = Optional.empty(), password = Optional.empty();
        try {
            properties.load(new FileReader(DATABASE_FILE));
            databaseUrl = Optional.ofNullable(properties.getProperty("databaseUrl"));
            username = Optional.ofNullable(properties.getProperty("username"));
            password = Optional.ofNullable(properties.getProperty("password"));
        } catch (IOException e) {
            String fileErrorMessage = "Pogreška pri čitanju properties datoteke!";
            logger.error(fileErrorMessage);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(fileErrorMessage);
            alert.showAndWait();
            LoginScreen.getMainStage().close();
        }
        return DriverManager.getConnection(databaseUrl.get(), username.get(), password.get());
    }

    public static void bazaPodatakaAlert(BazaPodatakaException e) {
        logger.error(message, e);
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(e.getMessage());
        alert.showAndWait();
        LoginScreen.getMainStage().close();
    }

    public static List<Role> getRoleBy(Role role) throws BazaPodatakaException {
        List<Role> roleList = new ArrayList<>();
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat uloga.");
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM ROLE WHERE 1 = 1");
            if (Optional.ofNullable(role).isPresent()) {
                logger.info("Poslan zahtjev za role iz baze s filterom.");
                if (Optional.of(role).map(Role::id).isPresent()) {
                    sqlQuery.append(" AND ID = ").append(role.id());
                }
                if (!Optional.ofNullable(role.name()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(role.name()).append("%'");
                if (Optional.ofNullable(role.passwordHash()).isPresent())
                    sqlQuery.append(" AND PASSWORD = ").append(role.passwordHash());
            } else
                logger.info("Poslan zahtjev za ulogu iz baze bez filtera.");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za ulogu prema bazi.");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Integer password = resultSet.getInt("password");
                Role newRole = new Role(id, name, password);
                roleList.add(newRole);
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim ulogama iz baze.");
        return roleList;
    }
    public synchronized static List<Pokemon> getPokemonBy(Pokemon pokemon) throws BazaPodatakaException {
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat pokemona.");
            Set<Ability> abilitySetInput = new HashSet<>();
            Set<Type> typeSetInput = new HashSet<>();
            Set<EggGroup> eggSetInput = new HashSet<>();
            Map<LearnableMovesType, Set<Move>> moveMapInput = new HashMap<>();

            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM POKEDEX WHERE 1 = 1");
            if (Optional.ofNullable(pokemon).isPresent()) {
                logger.info("Poslan zahtjev za pokemonima iz baze s filterom.");
                if (Optional.of(pokemon).map(Pokemon::getId).isPresent())
                    sqlQuery.append(" AND ID = ").append(pokemon.getId());
                if (!Optional.ofNullable(pokemon.getName()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(pokemon.getName()).append("%'");
                if (Optional.ofNullable(pokemon.getPokedexNumber()).isPresent())
                    sqlQuery.append(" AND NUMBER = ").append(pokemon.getPokedexNumber());
                if (Optional.ofNullable(pokemon.getBaseStats()).isPresent()) {
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND HP = ").append(pokemon.getBaseStats().hp());
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND ATT = ").append(pokemon.getBaseStats().attack());
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND S_ATT = ").append(pokemon.getBaseStats().spAttack());
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND DEF = ").append(pokemon.getBaseStats().defense());
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND S_DEF = ").append(pokemon.getBaseStats().spDefense());
                    if (Optional.ofNullable(pokemon.getBaseStats().hp()).isPresent())
                        sqlQuery.append(" AND SP = ").append(pokemon.getBaseStats().speed());
                }
                if (Optional.ofNullable(pokemon.getAllAbilities()).isPresent())
                    abilitySetInput = pokemon.getAllAbilities();
                if (Optional.ofNullable(pokemon.getType()).isPresent())
                    typeSetInput = pokemon.getType();
                if (Optional.ofNullable(pokemon.getEggGroups()).isPresent())
                    eggSetInput = pokemon.getEggGroups();
                if (Optional.ofNullable(pokemon.getLearnableMoves()).isPresent())
                    moveMapInput = pokemon.getLearnableMoves();
            } else
                logger.info("Poslan zahtjev za pokemonima iz baze bez filtera");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za pokemone prema bazi.");
            ExecutorService executorService = Executors.newCachedThreadPool();
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                Integer pokedexNumber = resultSet.getInt("number");
                String name = resultSet.getString("name");
                Integer hp = resultSet.getInt("hp");
                Integer attack = resultSet.getInt("att");
                Integer spAttack = resultSet.getInt("s_att");
                Integer defense = resultSet.getInt("def");
                Integer spDefense = resultSet.getInt("s_def");
                Integer speed = resultSet.getInt("sp");

                BaseStats baseStats = new BaseStats(hp, attack, spAttack, defense, spDefense, speed);
                Connection threadConnection = connectToBase();
                Pokemon pokemonInput = new Pokemon.Builder(id, name)
                        .setPokedexNumber(pokedexNumber)
                        .setAllAbilities(abilitySetInput)
                        .setBaseStats(baseStats)
                        .setType(typeSetInput)
                        .setLearnableMoves(moveMapInput)
                        .setEggGroups(eggSetInput)
                        .build();
                PokemonGetThread pokemonGetThread = new PokemonGetThread(pokemonInput, threadConnection);
                pokemonList.clear();
                executorService.execute(pokemonGetThread);
            }
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(1, TimeUnit.MINUTES)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException ex) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim pokemonima iz baze.");
        return pokemonList;
    }
    public static List<TeamPokemon> getTeamPokemonBy(TeamPokemon teamPokemon) throws BazaPodatakaException {
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat team pokemona.");
            Set<Move> moveSet = new HashSet<>();

            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM TEAM_POKEMON WHERE 1 = 1");
            if (Optional.ofNullable(teamPokemon).isPresent()) {
                logger.info("Poslan zahtjev za team pokemonima iz baze s filterom.");
                if (Optional.of(teamPokemon).map(TeamPokemon::getId).isPresent())
                    sqlQuery.append(" AND ID = ").append(teamPokemon.getId());
                if (Optional.ofNullable(teamPokemon.getPokemon()).isPresent())
                    sqlQuery.append(" AND POKEMON_ID = ").append(teamPokemon.getPokemon().getId());
                if (Optional.ofNullable(teamPokemon.getAbility()).isPresent())
                    sqlQuery.append(" AND ABILITY_ID = ").append(teamPokemon.getAbility().getId());
                if (Optional.ofNullable(teamPokemon.getTeraType()).isPresent())
                    sqlQuery.append(" AND TERA_TYPE_ID = ").append(teamPokemon.getTeraType().getId());
                if (Optional.ofNullable(teamPokemon.getMoves()).isPresent())
                    moveSet = teamPokemon.getMoves();
            } else
                logger.info("Poslan zahtjev za team pokemonima iz baze bez filtera");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za team pokemone prema bazi.");
            ExecutorService executorService = Executors.newCachedThreadPool();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                Long pokemonId = resultSet.getLong("pokemon_id");
                Long abilityId = resultSet.getLong("ability_id");
                Long teraTypeId = resultSet.getLong("tera_type_id");

                Connection threadConnection = connectToBase();
                List<Long> idList = new ArrayList<>();
                Collections.addAll(idList, pokemonId, abilityId, teraTypeId);
                ThreadInputData<Move, Set<Move>> threadInputData = new ThreadInputData<>(moveSet, idList, id);
                TeamPokemonGetThread teamPokemonGetThread = new TeamPokemonGetThread(threadInputData, threadConnection);
                teamPokemonList.clear();
                executorService.execute(teamPokemonGetThread);
            }
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(1, TimeUnit.MINUTES)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException ex) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim pokemonima u timu iz baze.");
        return teamPokemonList;
    }
    public static List<Ability> getAbilityBy(Ability ability) throws BazaPodatakaException {
        List<Ability> abilityList = new ArrayList<>();
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat ability.");
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM ABILITY WHERE 1 = 1");
            if (Optional.ofNullable(ability).isPresent()) {
                logger.info("Poslan zahtjev za ability iz baze s filterom.");
                if (Optional.of(ability).map(Ability::getId).isPresent()) {
                    sqlQuery.append(" AND ID = ").append(ability.getId());
                }
                if (!Optional.ofNullable(ability.getName()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(ability.getName()).append("%'");
            } else
                logger.info("Poslan zahtjev za ability iz baze bez filtera.");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za ability prema bazi.");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Ability newAbility = new Ability(id, name);
                abilityList.add(newAbility);
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim ability iz baze.");
        return abilityList;
    }
    public static List<Type> getTypeBy(Type type) throws BazaPodatakaException {
        List<Type> typeList = new ArrayList<>();
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat type.");
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM TYPE WHERE 1 = 1");
            if (Optional.ofNullable(type).isPresent()) {
                logger.info("Poslan zahtjev za type iz baze s filterom.");
                if (Optional.of(type).map(Type::getId).isPresent()) {
                    sqlQuery.append(" AND ID = ").append(type.getId());
                }
                if (!Optional.ofNullable(type.getName()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(type.getName()).append("%'");
            } else
                logger.info("Poslan zahtjev za type iz baze bez filtera.");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za type prema bazi.");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Type newType = new Type(id, name);
                typeList.add(newType);
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim type iz baze.");
        typeList.sort(new TypeSorter());
        return typeList;
    }
    public static List<Move> getMoveBy(Move move) throws BazaPodatakaException {
        List<Move> moveList = new ArrayList<>();
        List<Type> typeList = getTypeBy(null);
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat napada.");
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM MOVE WHERE 1 = 1");
            if (Optional.ofNullable(move).isPresent()) {
                logger.info("Poslan zahtjev za napade iz baze s filterom.");
                if (Optional.of(move).map(Move::getId).isPresent()) {
                    sqlQuery.append(" AND ID = ").append(move.getId());
                }
                if (!Optional.ofNullable(move.getName()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(move.getName()).append("%'");
                if (Optional.ofNullable(move.getMoveType()).isPresent())
                    sqlQuery.append(" AND MOVE_TYPE = ").append(move.getMoveType().getType());
                if (Optional.ofNullable(move.getPokemonType()).isPresent())
                    sqlQuery.append(" AND TYPE_ID = ").append(move.getPokemonType().getId());
            } else
                logger.info("Poslan zahtjev za napade iz baze bez filtera.");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za napade prema bazi.");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Long typeId = resultSet.getLong("type_id");
                String moveTypeName = resultSet.getString("move_type");

                Optional<Type> optionalType = typeList.stream().filter(type1 -> type1.getId().equals(typeId)).findFirst();
                if (optionalType.isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Type id ne postoji!");
                    alert.showAndWait();
                    LoginScreen.getMainStage().close();
                }

                MoveType moveType = null;
                try {
                    moveType = MoveType.valueOf(moveTypeName.toUpperCase());
                } catch (IllegalArgumentException e) {
                    QuickDialog.dialogError("Zadani move type ne postoji!");
                    LoginScreen.getMainStage().close();
                }

                Move newMove = new Move(id, name, optionalType.get(), moveType);
                moveList.add(newMove);
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim napadima iz baze.");
        return moveList;
    }
    public static List<EggGroup> getEggGroupBy(EggGroup eggGroup) throws BazaPodatakaException {
        List<EggGroup> eggGroupList = new ArrayList<>();
        try (Connection connection = connectToBase()) {
            logger.info("Uspješno spajanje s bazom za dohvat egg group.");
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM EGG_GROUP WHERE 1 = 1");
            if (Optional.ofNullable(eggGroup).isPresent()) {
                if (Optional.of(eggGroup).map(EggGroup::getId).isPresent()) {
                    sqlQuery.append(" AND ID = ").append(eggGroup.getId());
                }
                if (!Optional.ofNullable(eggGroup.getName()).map(String::isBlank).orElse(true))
                    sqlQuery.append(" AND NAME LIKE '%").append(eggGroup.getName()).append("%'");
            } else
                logger.info("Poslan zahtjev za egg group iz baze s filterom.");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery.toString());
            logger.info("Izvršen upit za egg group prema bazi.");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                EggGroup newGroup = new EggGroup(id, name);
                eggGroupList.add(newGroup);
            }
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        logger.info("Vraća se lista s filtriranim egg group iz baze.");
        return eggGroupList;
    }

    public static Ability addAbility(String name) throws BazaPodatakaException, SameNameException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getAbilityBy(null).stream().mapToLong(Entitet::getId).max();
            if (getAbilityBy(new Ability(null, name)).stream().anyMatch(ability -> ability.getName().equals(name)))
                throw new SameNameException("Ability s imenom " + name + " već postoji!");

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO ABILITY(id, name) VALUES(?, ?)");
            preparedStatement.setLong(1, max.getAsLong() + 1);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        return new Ability(max.getAsLong() + 1, name);
    }
    public static Optional<Ability> removeAbility(String name) throws BazaPodatakaException {
        Optional<Ability> optionalAbility = getAbilityBy(new Ability(null, name)).stream().filter(ability -> ability.getName().equals(name)).findFirst();
        if (optionalAbility.isPresent()) {
            try (Connection connection = connectToBase()) {
                connection.createStatement().execute("DELETE FROM ABILITY WHERE NAME = '" + name + "'");
            } catch (SQLException e) {
                throw new BazaPodatakaException(message, e);
            }
        }
        return optionalAbility;
    }
    public static EggGroup addEggGroup(String name) throws BazaPodatakaException, SameNameException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getEggGroupBy(null).stream().mapToLong(Entitet::getId).max();
            if (getEggGroupBy(new EggGroup(null, name)).stream().anyMatch(eggGroup -> eggGroup.getName().equals(name)))
                throw new SameNameException("Egg group s imenom " + name + " već postoji!");

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO EGG_GROUP(id, name) VALUES(?, ?)");
            preparedStatement.setLong(1, max.getAsLong() + 1);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        return new EggGroup(max.getAsLong() + 1, name);
    }
    public static Optional<EggGroup> removeEggGroup(String name) throws BazaPodatakaException {
        Optional<EggGroup> optionalEggGroup = getEggGroupBy(new EggGroup(null, name)).stream().filter(eggGroup -> eggGroup.getName().equals(name)).findFirst();
        if (optionalEggGroup.isPresent()) {
            try (Connection connection = connectToBase()) {
                connection.createStatement().execute("DELETE FROM EGG_GROUP WHERE NAME = '" + name + "'");
            } catch (SQLException e) {
                throw new BazaPodatakaException(message, e);
            }
        }
        return optionalEggGroup;
    }
    public static Move addMove(Move move) throws BazaPodatakaException, SameNameException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getMoveBy(null).stream().mapToLong(Entitet::getId).max();
            if (getMoveBy(new Move(null, move.getName())).stream().anyMatch(move1 -> move1.getName().equals(move.getName())))
                throw new SameNameException("Napad s imenom " + move.getName() + " već postoji!");

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO MOVE(id, name, type_id, move_type) VALUES(?, ?, ?, ?)");
            preparedStatement.setLong(1, max.getAsLong() + 1);
            preparedStatement.setString(2, move.getName());
            preparedStatement.setLong(3, move.getPokemonType().getId());
            preparedStatement.setString(4, move.getMoveType().name().toLowerCase());
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        return new Move(max.getAsLong() + 1, move.getName(), move.getPokemonType(), move.getMoveType());
    }
    public static Optional<Move> removeMove(String name) throws BazaPodatakaException {
        Optional<Move> optionalMove = getMoveBy(new Move(null, name)).stream().filter(move -> move.getName().equals(name)).findFirst();
        if (optionalMove.isPresent()) {
            try (Connection connection = connectToBase()) {
                connection.createStatement().execute("DELETE FROM MOVE WHERE NAME = '" + name + "'");
            } catch (SQLException e) {
                throw new BazaPodatakaException(message, e);
            }
        }
        return optionalMove;
    }
    public static Type addType(String name) throws BazaPodatakaException, SameNameException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getTypeBy(null).stream().mapToLong(Entitet::getId).max();
            if (getTypeBy(new Type(null, name)).stream().anyMatch(ability -> ability.getName().equals(name)))
                throw new SameNameException("Type s imenom " + name + " već postoji!");

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO TYPE(id, name) VALUES(?, ?)");
            preparedStatement.setLong(1, max.getAsLong() + 1);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        return new Type(max.getAsLong() + 1, name);
    }
    public static Optional<Pokemon> removePokemon(String name) throws BazaPodatakaException {
        Optional<Pokemon> optionalPokemon = getPokemonBy(new Pokemon.Builder(null, name).build()).stream().filter(pokemon -> pokemon.getName().equals(name)).findFirst();
        if (optionalPokemon.isPresent()) {
            try (Connection connection = connectToBase()) {
                connection.createStatement().execute("DELETE FROM POKEDEX_ABILITY WHERE POKEMON_ID = " + optionalPokemon.get().getId());
                connection.createStatement().execute("DELETE FROM POKEDEX_EGG_GROUP WHERE POKEMON_ID = " + optionalPokemon.get().getId());
                connection.createStatement().execute("DELETE FROM POKEDEX_MOVES WHERE POKEMON_ID = " + optionalPokemon.get().getId());
                connection.createStatement().execute("DELETE FROM POKEDEX_TYPE WHERE POKEMON_ID = " + optionalPokemon.get().getId());
                connection.createStatement().execute("DELETE FROM POKEDEX WHERE NAME = '" + name + "'");
            } catch (SQLException e) {
                throw new BazaPodatakaException(message, e);
            }
        }
        return optionalPokemon;
    }
    public static Optional<Type> removeType(String name) throws BazaPodatakaException {
        Optional<Type> optionalType = getTypeBy(new Type(null, name)).stream().filter(type -> type.getName().equals(name)).findFirst();
        if (optionalType.isPresent()) {
            try (Connection connection = connectToBase()) {
                connection.createStatement().execute("DELETE FROM TYPE WHERE NAME = '" + name + "'");
            } catch (SQLException e) {
                throw new BazaPodatakaException(message, e);
            }
        }
        return optionalType;
    }
    public static Pokemon addPokemon(Pokemon pokemon) throws BazaPodatakaException, SameNameException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getPokemonBy(null).stream().mapToLong(Entitet::getId).max();
            if (getPokemonBy(new Pokemon.Builder(null, pokemon.getName()).build()).stream().anyMatch(pokemon1 -> pokemon1.getName().equals(pokemon.getName())))
                throw new SameNameException("Pokemon s imenom " + pokemon.getName() + " već postoji!");

            connection.setAutoCommit(false);

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO POKEDEX(id, number, name, hp, att, s_att, def, s_def, sp) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement.setLong(1, max.getAsLong() + 1);
            preparedStatement.setInt(2, pokemon.getPokedexNumber());
            preparedStatement.setString(3, pokemon.getName());
            preparedStatement.setInt(4, pokemon.getBaseStats().hp());
            preparedStatement.setInt(5, pokemon.getBaseStats().attack());
            preparedStatement.setInt(6, pokemon.getBaseStats().spAttack());
            preparedStatement.setInt(7, pokemon.getBaseStats().defense());
            preparedStatement.setInt(8, pokemon.getBaseStats().spDefense());
            preparedStatement.setInt(9, pokemon.getBaseStats().speed());
            preparedStatement.executeUpdate();

            for (Ability ability : pokemon.getAllAbilities()) {
                PreparedStatement preparedStatementAbility = connection.prepareStatement("INSERT INTO POKEDEX_ABILITY(pokemon_id, ability_id, hidden) VALUES(?, ?, ?)");
                preparedStatementAbility.setLong(1,max.getAsLong() + 1);
                preparedStatementAbility.setLong(2, ability.getId());
                preparedStatementAbility.setBoolean(3, ability.getHidden());
                preparedStatementAbility.executeUpdate();
            }

            for (EggGroup eggGroup : pokemon.getEggGroups()) {
                PreparedStatement prepareStatementEggGroup = connection.prepareStatement("INSERT INTO POKEDEX_EGG_GROUP(pokemon_id, egg_group_id) VALUES(?, ?)");
                prepareStatementEggGroup.setLong(1, max.getAsLong() + 1);
                prepareStatementEggGroup.setLong(2, eggGroup.getId());
                prepareStatementEggGroup.executeUpdate();
            }

            for (Type type : pokemon.getType()) {
                PreparedStatement prepareStatementType = connection.prepareStatement("INSERT INTO POKEDEX_TYPE(pokemon_id, type_id) VALUES(?, ?)");
                prepareStatementType.setLong(1, max.getAsLong() + 1);
                prepareStatementType.setLong(2, type.getId());
                prepareStatementType.executeUpdate();
            }

            for (LearnableMovesType learnableMovesType : LearnableMovesType.values()) {
                for (Move move : pokemon.getLearnableMoves().get(learnableMovesType)) {
                    PreparedStatement prepareStatementMove = connection.prepareStatement("INSERT INTO POKEDEX_MOVES(pokemon_id, move_id, learnable_move_type) VALUES(?, ?, ?)");
                    prepareStatementMove.setLong(1, max.getAsLong() + 1);
                    prepareStatementMove.setLong(2, move.getId());
                    prepareStatementMove.setInt(3, learnableMovesType.getId());
                    prepareStatementMove.executeUpdate();
                }
            }

            connection.setAutoCommit(true);
            connection.commit();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        pokemon.setId(max.getAsLong() + 1);
        return pokemon;
    }
    public static TeamPokemon addTeamPokemon(TeamPokemon teamPokemon) throws BazaPodatakaException {
        OptionalLong max;
        try (Connection connection = connectToBase()) {
            max = getTeamPokemonBy(null).stream().mapToLong(Entitet::getId).max();
            if (max.isEmpty())
                max = OptionalLong.of(0);

            connection.setAutoCommit(false);

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO TEAM_POKEMON(id, pokemon_id, ability_id, tera_type_id) VALUES(?, ?, ?, ?)");
            preparedStatement.setInt(1, Math.toIntExact(max.getAsLong()) + 1);
            preparedStatement.setLong(2, teamPokemon.getPokemon().getId());
            preparedStatement.setLong(3, teamPokemon.getAbility().getId());
            preparedStatement.setLong(4, teamPokemon.getTeraType().getId());
            preparedStatement.executeUpdate();

            for (Move move : teamPokemon.getMoves()) {
                PreparedStatement preparedStatementMoves = connection.prepareStatement("INSERT INTO TEAM_POKEMON_MOVES(team_pokemon_id, move_id) VALUES (?, ?)");
                preparedStatementMoves.setInt(1, Math.toIntExact(max.getAsLong()) + 1);
                preparedStatementMoves.setLong(2, move.getId());
                preparedStatementMoves.executeUpdate();
            }

            connection.setAutoCommit(true);
            connection.commit();
        } catch (SQLException ex) {
            throw new BazaPodatakaException(message, ex);
        }
        teamPokemon.setId(max.getAsLong() + 1);
        return teamPokemon;
    }
    public static void removeTeamPokemon(TeamPokemon teamPokemonInput) throws BazaPodatakaException {
        try (Connection connection = connectToBase()) {
            connection.createStatement().execute("DELETE FROM TEAM_POKEMON_MOVES WHERE TEAM_POKEMON_ID = " + teamPokemonInput.getId());
            connection.createStatement().execute("DELETE FROM TEAM_POKEMON WHERE ID = " + teamPokemonInput.getId());
        } catch (SQLException e) {
            throw new BazaPodatakaException(message, e);
        }
    }

    public static void importAbilities() {
        try (Connection connection = connectToBase()) {
            List<Ability> abilityList = new AbilityReader().read();
            long id = 0;
            for (Ability ability : abilityList) {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO ABILITY(id, name) VALUES (?, ?)");
                preparedStatement.setLong(1, ++id);
                preparedStatement.setString(2, ability.getName());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void importEggGroups() {
        try (Connection connection = connectToBase()) {
            List<EggGroup> eggGroupList = new EggReader().read();
            long id = 0;
            for (EggGroup eggGroup : eggGroupList) {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO EGG_GROUP(id, name) VALUES (?, ?)");
                preparedStatement.setLong(1, ++id);
                preparedStatement.setString(2, eggGroup.getName());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void importTypes() {
        try (Connection connection = connectToBase()) {
            List<Type> typeList = new TypeReader().read();
            long id = 0;
            for (Type type : typeList) {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO TYPE(id, name) VALUES (?, ?)");
                preparedStatement.setLong(1, ++id);
                preparedStatement.setString(2, type.getName());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void importMoves() {
        try (Connection connection = connectToBase()) {
            List<Move> moveList = new MoveReader().read();
            long id = 0;
            for (Move move : moveList) {
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO MOVE(id, name, type_id, move_type) VALUES (?, ?, ?, ?)");
                preparedStatement.setLong(1, ++id);
                preparedStatement.setString(2, move.getName());

                Optional<Type> optionalType = getTypeBy(null).stream().filter(type1 -> type1.getId().equals(move.getPokemonType().getId())).findFirst();
                if (optionalType.isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Type id ne postoji!");
                    alert.showAndWait();
                    LoginScreen.getMainStage().close();
                }
                preparedStatement.setLong(3, optionalType.get().getId());
                preparedStatement.setString(4, move.getMoveType().getType());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException | BazaPodatakaException e) {
            e.printStackTrace();
        }
    }
    public static void importPokedex() {
        try (Connection connection = connectToBase()) {
            List<Pokemon> pokemonList = new PokemonReader().read();
            long id = 0;
            for (Pokemon pokemon : pokemonList) {
                connection.setAutoCommit(false);
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO POKEDEX(id, number, name, hp, att, s_att, def, s_def, sp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                preparedStatement.setLong(1, ++id);
                preparedStatement.setInt(2, pokemon.getPokedexNumber());
                preparedStatement.setString(3, pokemon.getName());
                preparedStatement.setInt(4, pokemon.getBaseStats().hp());
                preparedStatement.setInt(5, pokemon.getBaseStats().attack());
                preparedStatement.setInt(6, pokemon.getBaseStats().spAttack());
                preparedStatement.setInt(7, pokemon.getBaseStats().defense());
                preparedStatement.setInt(8, pokemon.getBaseStats().spDefense());
                preparedStatement.setInt(9, pokemon.getBaseStats().speed());
                preparedStatement.executeUpdate();

                PreparedStatement preparedStatementMove = connection.prepareStatement(
                        "INSERT INTO POKEDEX_MOVES(pokemon_id, move_id, learnable_move_type) VALUES (" + id + ", ?, ?)");

                pokemon.getLearnableMoves().keySet().forEach(learnableMoveType -> {
                    pokemon.getLearnableMoves().get(learnableMoveType).forEach(move -> {
                        try {
                            preparedStatementMove.setLong(1, move.getId());
                            preparedStatementMove.setInt(2, learnableMoveType.getId());
                            preparedStatementMove.executeUpdate();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    });
                });

                PreparedStatement preparedStatementAbility = connection.prepareStatement(
                        "INSERT INTO POKEDEX_ABILITY(pokemon_id, ability_id, hidden) VALUES (" + id + ", ?, ?)");
                for (Ability ability : pokemon.getAllAbilities()) {
                    preparedStatementAbility.setLong(1, ability.getId());
                    preparedStatementAbility.setBoolean(2, ability.getHidden());
                    preparedStatementAbility.executeUpdate();
                }

                PreparedStatement preparedStatementEggGroup = connection.prepareStatement(
                        "INSERT INTO POKEDEX_EGG_GROUP(pokemon_id, egg_group_id) VALUES (" + id + ", ?)");
                for (EggGroup eggGroup : pokemon.getEggGroups()) {
                    preparedStatementEggGroup.setLong(1, eggGroup.getId());
                    preparedStatementEggGroup.executeUpdate();
                }

                PreparedStatement preparedStatementType = connection.prepareStatement(
                        "INSERT INTO POKEDEX_TYPE(pokemon_id, type_id) VALUES (" + id + ", ?)");
                for (Type type : pokemon.getType()) {
                    preparedStatementType.setLong(1, type.getId());
                    preparedStatementType.executeUpdate();
                }

                connection.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
