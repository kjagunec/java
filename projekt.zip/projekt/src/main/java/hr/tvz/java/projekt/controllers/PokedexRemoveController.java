package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.Ability;
import hr.tvz.java.projekt.entiteti.ChangeType;
import hr.tvz.java.projekt.entiteti.Pokemon;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import org.controlsfx.control.SearchableComboBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PokedexRemoveController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private SearchableComboBox<Pokemon> comboBox;
    private List<Pokemon> pokemonList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            pokemonList = BazaPodataka.getPokemonBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        comboBox.setItems(FXCollections.observableList(pokemonList));
    }

    @FXML
    private void remove() {
        if (Optional.ofNullable(comboBox.getValue()).isPresent()) {
            Alert alert = QuickDialog.potvrda("brisanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Optional<Pokemon> optionalPokemon = BazaPodataka.removePokemon(comboBox.getValue().getName());
                        if (optionalPokemon.isPresent()) {
                            String message = "Izbrisan pokemon imena: " + optionalPokemon.get().getName();
                            logger.info(message);
                            QuickDialog.dialogInfo(message);
                            Change<Pokemon> change = new Change<>(optionalPokemon.get(), LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                            change.addToDat();
                        }
                        else {
                            logger.warn("Pokušaj brisanja pokemona s imenom: " + comboBox.getValue().getName());
                            QuickDialog.dialogWarning("Ne postoji pokemon s imenom " + comboBox.getValue().getName());
                        }
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }
        }
    }
}
