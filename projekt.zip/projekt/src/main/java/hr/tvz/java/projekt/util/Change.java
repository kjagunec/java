package hr.tvz.java.projekt.util;

import hr.tvz.java.projekt.files.ChangeReader;
import hr.tvz.java.projekt.files.EndOfFile;
import hr.tvz.java.projekt.entiteti.ChangeType;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.entiteti.Entitet;
import hr.tvz.java.projekt.entiteti.Role;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.time.LocalDateTime;
import java.util.List;

public record Change<T extends Entitet>(T data, Role role, LocalDateTime dateTime,
                                        ChangeType changeType) implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);

    public void addToDat() {
        List<Change<Entitet>> changeList = ChangeReader.getChanges();
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("dat/change-log.dat"))) {
            for (Change<Entitet> change : changeList)
                out.writeObject(change);
            out.writeObject(this);
            out.writeObject(new EndOfFile());
            logger.info("Serijalizacija uspješna!");
        } catch (IOException e) {
            String message = "Serijalizacija neuspješna!";
            logger.error(message, e);
            QuickDialog.dialogError(message);
        }
    }
}
