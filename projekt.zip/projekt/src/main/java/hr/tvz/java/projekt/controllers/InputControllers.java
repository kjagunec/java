package hr.tvz.java.projekt.controllers;

public sealed interface InputControllers permits InputController {
    void confirm();
    void backToPokedex();
    void reset();
}
