package hr.tvz.java.projekt.entiteti;

public class Ability extends Entitet{
    private Boolean hidden = false;

    public Ability(Long id, String name) {
        super(id, name);
    }

    public Boolean getHidden() {
        return hidden;
    }

    public void setHidden(Boolean hidden) {
        this.hidden = hidden;
    }

    @Override
    public String toString() {
        return getName();
    }
}