package hr.tvz.java.projekt.util;

import hr.tvz.java.projekt.entiteti.*;

import java.util.*;

public record ThreadInputData<T extends Entitet, K extends Collection<T>>(K collection, List<Long> idList, Integer id) {
}
