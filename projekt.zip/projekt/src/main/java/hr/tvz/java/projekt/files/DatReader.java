package hr.tvz.java.projekt.files;

public abstract non-sealed class DatReader<T> implements Reader<T> {}
