package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.Ability;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.controlsfx.control.SearchableComboBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class AbilitiesInputController extends InputController<Ability> {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private SearchableComboBox<String> abilityComboBox;
    @FXML
    private SearchableComboBox<String> hiddenAbilityComboBox;
    @FXML
    private TableView<Ability> abilityTableView;
    @FXML
    private TableView<Ability> hiddenAbilityTableView;
    @FXML
    private TableColumn<Ability, String> abilityTableColumn;
    @FXML
    private TableColumn<Ability, String> hiddenAbilityTableColumn;
    @FXML
    private Button reset;
    private List<Ability> inputAbilityList = new ArrayList<>(PokedexAddController.inputAbilityList.stream().filter(ability -> !ability.getHidden()).toList());
    private List<Ability> inputHiddenAbilityList = new ArrayList<>(PokedexAddController.inputAbilityList.stream().filter(Ability::getHidden).toList());
    private List<Ability> abilityList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            abilityList = BazaPodataka.getAbilityBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        abilityList.forEach(ability -> abilityComboBox.getItems().add(ability.getName()));
        abilityList.forEach(ability -> hiddenAbilityComboBox.getItems().add(ability.getName()));

        abilityTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        hiddenAbilityTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        abilityTableView.setItems(FXCollections.observableList(inputAbilityList));
        hiddenAbilityTableView.setItems(FXCollections.observableList(inputHiddenAbilityList));

        logger.info("Egg groups input ekran inicijaliziran.");
    }

    @FXML
    public void confirm() {
        if (abilityTableView.getItems().isEmpty() && hiddenAbilityTableView.getItems().isEmpty()) {
            reset();
        }
        else {
            List<Ability> list = new ArrayList<>();
            if (!inputAbilityList.isEmpty())
                list.addAll(inputAbilityList);
            if (!inputHiddenAbilityList.isEmpty())
                list.addAll(inputHiddenAbilityList);
            if (!PokedexAddController.inputAbilityList.equals(list))
                PokedexAddController.inputAbilityList = list;
            logger.info("Spremljen popis upisanih abilitya.");
        }
        backToPokedex();
    }

    @FXML
    public void reset() {
        if (!abilityTableView.getItems().isEmpty())
            abilityTableView.getItems().clear();
        if (!hiddenAbilityTableView.getItems().isEmpty())
            hiddenAbilityTableView.getItems().clear();
        if (!PokedexAddController.inputAbilityList.isEmpty())
            PokedexAddController.inputAbilityList.clear();
        logger.info("Brisanje upisanih abilitya.");
    }

    @FXML
    private void addAbility() {
        if (Optional.ofNullable(abilityComboBox.getValue()).isPresent()) {
            if (abilityTableView.getItems().size() < 2) {
                try {
                    Optional<Ability> optionalAbility = BazaPodataka.getAbilityBy(new Ability(null, abilityComboBox.getValue().trim()))
                            .stream()
                            .filter(ability -> ability.getName().equals(abilityComboBox.getValue().trim()))
                            .findFirst();
                    if (optionalAbility.isPresent()) {
                        if (abilityTableView.getItems().stream().anyMatch(ability -> ability.getId().equals(optionalAbility.get().getId()) ||
                                hiddenAbilityTableView.getItems().stream().anyMatch(ability1 -> ability1.getId().equals(optionalAbility.get().getId())))) {
                            QuickDialog.dialogWarning("Pokemon ne može imati dva ista abilitya!");
                            logger.warn("Pokušaj dodavanja abilitya koji je već dodan.");
                        } else {
                            abilityTableView.getItems().add(optionalAbility.get());
                            logger.info("Dodan ability " + optionalAbility.get().getName() + " na popis.");
                        }
                    } else {
                        QuickDialog.dialogWarning("Ability s imenom " + abilityComboBox.getValue().trim() + " ne postoji!");
                        logger.warn("Pokušaj dodavanja ability koji ne postoji.");
                    }
                } catch (BazaPodatakaException e) {
                    BazaPodataka.bazaPodatakaAlert(e);
                }
            } else {
                QuickDialog.dialogWarning("Pokemon može imati najviše dva abilitya!");
            }
        }
    }
    @FXML
    private void addHiddenAbility() {
        if (Optional.ofNullable(hiddenAbilityComboBox.getValue()).isPresent()) {
            if (hiddenAbilityTableView.getItems().isEmpty()) {
                try {
                    Optional<Ability> optionalAbility = BazaPodataka.getAbilityBy(new Ability(null, hiddenAbilityComboBox.getValue().trim()))
                            .stream()
                            .filter(ability -> ability.getName().equals(hiddenAbilityComboBox.getValue().trim()))
                            .findFirst();
                    if (optionalAbility.isPresent()) {
                        if (hiddenAbilityTableView.getItems().stream().anyMatch(ability -> ability.getId().equals(optionalAbility.get().getId())) ||
                                hiddenAbilityTableView.getItems().stream().anyMatch(ability -> ability.getId().equals(optionalAbility.get().getId()))) {
                            QuickDialog.dialogWarning("Pokemon ne može imati dva ista abilitya!");
                            logger.warn("Pokušaj dodavanja abilitya koji je već dodan.");
                        } else {
                            optionalAbility.get().setHidden(true);
                            hiddenAbilityTableView.getItems().add(optionalAbility.get());
                            logger.info("Dodan hidden ability " + optionalAbility.get().getName() + " na popis.");
                        }
                    } else {
                        QuickDialog.dialogWarning("Ability s imenom " + abilityComboBox.getValue().trim() + " ne postoji!");
                        logger.warn("Pokušaj dodavanja ability koji ne postoji.");
                    }
                } catch (BazaPodatakaException e) {
                    BazaPodataka.bazaPodatakaAlert(e);
                }
            } else {
                QuickDialog.dialogWarning("Pokemon može imati samo jedan hidden ability!");
            }
        }
    }


    @FXML
    public void backToPokedex() {
        Stage stage = (Stage) abilityTableView.getScene().getWindow();
        stage.close();
        logger.info("Natrag na pokedex search ekrana s ability input ekrana.");
    }
}
