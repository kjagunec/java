package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.Role;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class LoginController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    public static Role currentRole;
    @FXML
    private TextField ime;
    @FXML
    private PasswordField lozinka;

    @FXML
    private void prijava() {
        List<Role> roleList = new ArrayList<>();
        try {
            roleList = BazaPodataka.getRoleBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }
        Optional<Role> roleOptional = roleList
                .stream()
                .filter(role -> role.name().equals(ime.getText().trim())
                        && role.passwordHash().equals(lozinka.getText().trim().hashCode()))
                .findAny();
        if (roleOptional.isPresent()) {
            currentRole = roleOptional.get();
            logger.info("Trenutna uloga je: " + currentRole.name());
            try {
                LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource("pocetni.fxml"))));
            } catch (IOException e) {
                String message = "Neuspješno otvaranje početne stranice!";
                QuickDialog.dialogError(message);
                logger.error(message, e);
            }
        } else {
            String message = "Korisničko ime ili lozinka nisu ispravni!";
            QuickDialog.dialogWarning(message);
            logger.warn(message);
        }
    }
}