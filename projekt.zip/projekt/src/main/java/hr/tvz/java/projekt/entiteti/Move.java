package hr.tvz.java.projekt.entiteti;

public class Move extends Entitet{
    private Type pokemonType;
    private MoveType moveType;

    public Move(Long id) {
        super(id);
    }
    public Move(Long id, String name, Type pokemonType, MoveType moveType) {
        super(id, name);
        this.pokemonType = pokemonType;
        this.moveType = moveType;
    }
    public Move(Long id, String name) {
        super(id, name);
    }

    public Type getPokemonType() {
        return pokemonType;
    }

    public MoveType getMoveType() {
        return moveType;
    }

    @Override
    public String toString() {
        return super.getName();
    }
}