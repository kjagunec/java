package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.EggGroup;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.controlsfx.control.SearchableComboBox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EggGroupsInputController extends InputController<EggGroup> {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private SearchableComboBox<String> eggGroupsComboBox;
    @FXML
    private TableView<EggGroup> eggGroupTableView;
    @FXML
    private TableColumn<EggGroup, String> eggGroupTableColumn;
    private List<EggGroup> eggGroupList = new ArrayList<>();
    private List<EggGroup> inputEggGroupList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            eggGroupList = BazaPodataka.getEggGroupBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        eggGroupList.forEach(eggGroup -> eggGroupsComboBox.getItems().add(eggGroup.getName()));

        inputEggGroupList.addAll(PokedexAddController.inputEggGroupList);

        eggGroupTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        eggGroupTableView.setItems(FXCollections.observableList(inputEggGroupList));
        logger.info("Egg groups input ekran inicijaliziran.");
    }

    @FXML
    public void confirm() {
        if (eggGroupTableView.getItems().isEmpty())
            reset();
        else {
            PokedexAddController.inputEggGroupList = inputEggGroupList;
            logger.info("Spremljen popis upisanih egg groupa.");
        }
        backToPokedex();
    }
    @FXML
    public void reset() {
        if (!eggGroupTableView.getItems().isEmpty()) {
            eggGroupTableView.getItems().clear();
            PokedexAddController.inputEggGroupList.clear();
            logger.info("Brisanje upisanih egg groupa.");
        }
    }
    @FXML
    public void backToPokedex() {
        Stage stage = (Stage) eggGroupsComboBox.getScene().getWindow();
        stage.close();
        logger.info("Natrag na pokedex search ekrana s egg group input ekrana.");
    }

    @FXML
    private void add() {
        if (Optional.ofNullable(eggGroupsComboBox.getValue()).isPresent()) {
            try {
                Optional<EggGroup> optionalEggGroup = BazaPodataka.getEggGroupBy(new EggGroup(null, eggGroupsComboBox.getValue().trim()))
                        .stream()
                        .filter(eggGroup -> eggGroup.getName().equals(eggGroupsComboBox.getValue().trim()))
                        .findFirst();
                if (optionalEggGroup.isPresent()) {
                    if (eggGroupTableView.getItems().stream().anyMatch(eggGroup -> eggGroup.getId().equals(optionalEggGroup.get().getId()))) {
                        QuickDialog.dialogWarning("Pokemon ne može imati dvije iste egg grupe!");
                        logger.warn("Pokušaj dodavanja egg grupe koja je već dodana.");
                    } else {
                        eggGroupTableView.getItems().add(optionalEggGroup.get());
                        logger.info("Dodan egg group " + optionalEggGroup.get().getName() + " na popis.");
                    }
                } else {
                    QuickDialog.dialogWarning("Egg group s imenom " + eggGroupsComboBox.getValue().trim() + " ne postoji!");
                    logger.warn("Pokušaj dodavanja egg group koji ne postoji.");
                }
            } catch (BazaPodatakaException e) {
                BazaPodataka.bazaPodatakaAlert(e);
            }
        }
    }
}
