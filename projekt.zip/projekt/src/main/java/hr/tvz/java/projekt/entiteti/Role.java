package hr.tvz.java.projekt.entiteti;

import java.io.Serializable;

public record Role(Long id, String name, Integer passwordHash) implements Serializable {
    public Long id() {
        return id;
    }

    public String name() {
        return name;
    }

    public Integer passwordHash() {
        return passwordHash;
    }
}
