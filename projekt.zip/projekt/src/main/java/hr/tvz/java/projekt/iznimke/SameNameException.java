package hr.tvz.java.projekt.iznimke;

public class SameNameException extends RuntimeException{
    public SameNameException() {
    }

    public SameNameException(String message) {
        super(message);
    }

    public SameNameException(String message, Throwable cause) {
        super(message, cause);
    }

    public SameNameException(Throwable cause) {
        super(cause);
    }
}
