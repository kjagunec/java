package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;

public class IzbornikController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private Menu changesMenu;
    @FXML
    private MenuItem removePokemon;

    @FXML
    private void initialize() {
        if (LoginController.currentRole.id().equals(1L)) {
            changesMenu.setVisible(true);
            removePokemon.setVisible(true);
        }
    }
    @FXML
    public void prikaziPokedexSearch() {
        String fxml = "pokedexSearch.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziPokedexAdd() {
        String fxml = "pokedexAdd.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziPokedexRemove() {
        String fxml = "pokedexRemove.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziMoves() {
        String fxml = "moves.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziTypes() {
        String fxml = "types.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziEggGroups() {
        String fxml = "eggGroups.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziAbilites() {
        String fxml = "abilities.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziMyTeam() {
        String fxml = "myTeam.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziLogin() {
        String fxml = "login.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(LoginScreen.class.getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    public void prikaziChanges() {
        String fxml = "changes.fxml";
        try {
            LoginScreen.setMainPage(FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxml))));
        } catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
}
