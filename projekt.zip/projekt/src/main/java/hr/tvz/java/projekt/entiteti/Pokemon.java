package hr.tvz.java.projekt.entiteti;

import javafx.scene.image.ImageView;

import java.util.Map;
import java.util.Set;

public class Pokemon extends Entitet{
    private Integer pokedexNumber;
    private Set<Type> type;
    private Map<LearnableMovesType, Set<Move>> learnableMoves;
    private Set<Ability> allAbilities;
    private BaseStats baseStats;
    private Set<EggGroup> eggGroups;
    private ImageView imageView;

    public static class Builder {
        private final Long id;
        private Integer pokedexNumber;
        private final String name;
        private Set<Type> type;
        private Map<LearnableMovesType, Set<Move>> learnableMoves;
        private Set<Ability> allAbilities;
        private BaseStats baseStats;
        private Set<EggGroup> eggGroups;
        private ImageView imageView;

        public Builder(Long id, String name) {
            this.id = id;
            this.name = name;
        }

        public Builder setAllAbilities(Set<Ability> allAbilities) {
            this.allAbilities = allAbilities;
            return this;
        }
        public Builder setPokedexNumber(Integer pokedexNumber) {
            this.pokedexNumber = pokedexNumber;
            return this;
        }
        public Builder setType (Set<Type> type) {
            this.type = type;
            return this;
        }
        public Builder setLearnableMoves(Map<LearnableMovesType, Set<Move>> learnableMoves) {
            this.learnableMoves = learnableMoves;
            return this;
        }
        public Builder setBaseStats(BaseStats baseStats) {
            this.baseStats = baseStats;
            return this;
        }
        public Builder setEggGroups(Set<EggGroup> eggGroups) {
            this.eggGroups = eggGroups;
            return this;
        }
        public Builder setImageView(ImageView imageView) {
            this.imageView = imageView;
            return this;
        }
        public Pokemon build() {
            Pokemon pokemon = new Pokemon(id, name);
            pokemon.allAbilities = allAbilities;
            pokemon.pokedexNumber = pokedexNumber;
            pokemon.type = type;
            pokemon.learnableMoves = learnableMoves;
            pokemon.baseStats = baseStats;
            pokemon.eggGroups = eggGroups;
            pokemon.imageView = imageView;
            return pokemon;
        }
    }

    private Pokemon(Long id, String name) {
        super(id, name);
    }

    public Integer getPokedexNumber() {
        return pokedexNumber;
    }

    public void setPokedexNumber(Integer pokedexNumber) {
        this.pokedexNumber = pokedexNumber;
    }

    public Set<Type> getType() {
        return type;
    }

    public void setType(Set<Type> type) {
        this.type = type;
    }

    public Map<LearnableMovesType, Set<Move>> getLearnableMoves() {
        return learnableMoves;
    }

    public void setLearnableMoves(Map<LearnableMovesType, Set<Move>> learnableMoves) {
        this.learnableMoves = learnableMoves;
    }

    public Set<Ability> getAllAbilities() {
        return allAbilities;
    }

    public void setAllAbilities(Set<Ability> allAbilities) {
        this.allAbilities = allAbilities;
    }

    public BaseStats getBaseStats() {
        return baseStats;
    }

    public void setBaseStats(BaseStats baseStats) {
        this.baseStats = baseStats;
    }

    public Set<EggGroup> getEggGroups() {
        return eggGroups;
    }

    public void setEggGroups(Set<EggGroup> eggGroups) {
        this.eggGroups = eggGroups;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    @Override
    public String toString() {
        return getName();
    }
}
