package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Entitet;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ChangeReader {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    private static final String fileLocation = "dat/change-log.dat";

    public static List<Change<Entitet>> getChanges() {
        List<Change<Entitet>> changeList = new ArrayList<>();
        if (Files.exists(Path.of(fileLocation))) {
            logger.info("Nađena datoteka na lokaciji " + fileLocation);
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileLocation))) {
                Object object;
                //ability, egg, move, pokemon, type, team
                while (!((object = in.readObject()) instanceof EndOfFile)) {
                    Change<Entitet> change = (Change<Entitet>) object;
                    changeList.add(change);
                }
            } catch (IOException e) {
                String message = "Otvaranje datoteke za serijalizaciju neuspješno!";
                logger.error(message, e);
                QuickDialog.dialogError(message);
            } catch (ClassNotFoundException e) {
                String message = "Pogreška pri castanju klase!";
                logger.error(message, e);
                QuickDialog.dialogError(message);
            }
        } else {
            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileLocation))) {
                out.writeObject(new EndOfFile());
            } catch (IOException e) {
                String message = "Otvaranje datoteke za serijalizaciju neuspješno!";
                logger.error(message, e);
                QuickDialog.dialogError(message);
            }
        }
        return changeList;
    }
}
