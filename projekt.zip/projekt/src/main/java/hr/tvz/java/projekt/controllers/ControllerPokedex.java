package hr.tvz.java.projekt.controllers;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public interface ControllerPokedex {
    void search();
    void add();
    void remove();
    default void dodavanjeDat(List<String> datString, TextField textField, String fileLocation) {
        try (BufferedWriter dat = new BufferedWriter(new FileWriter(fileLocation))) {
            for (String string : datString) {
                dat.write(string);
                dat.newLine();
            }
            dat.write(String.valueOf(Long.parseLong(datString.get(datString.size() - 2)) + 1));
            dat.newLine();
            dat.write(textField.getText());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    default void brisanjeDat(List<String> datString, TextField textField, String fileLocation) {
        try (BufferedWriter dat = new BufferedWriter(new FileWriter(fileLocation))) {
            for (int i = 0; i < datString.size() / 2; i++) {
                if (!datString.get(i * 2 + 1).equals(textField.getText())) {
                    dat.write(datString.get(i * 2));
                    dat.newLine();
                    dat.write(datString.get(i * 2 + 1));
                    dat.newLine();
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
