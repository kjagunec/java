package hr.tvz.java.projekt.thread;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.ThreadInputData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TeamPokemonGetThread implements Runnable{
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    private final ThreadInputData<Move, Set<Move>> threadInputData;
    private final Connection connection;

    public TeamPokemonGetThread(ThreadInputData<Move, Set<Move>> threadInputData, Connection connection) {
        this.threadInputData = threadInputData;
        this.connection = connection;
    }

    @Override
    public void run() {
        try {
            Pokemon pokemon;

                //System.out.println("Dretva " + Thread.currentThread().getName() + " ušla u synchronized");
                pokemon = BazaPodataka.getPokemonBy(new Pokemon.Builder(threadInputData.idList().get(0), null).build()).get(0);

            //System.out.println("Dretva " + Thread.currentThread().getName() + " izašla iz synchronized");
            Ability ability = BazaPodataka.getAbilityBy(new Ability(threadInputData.idList().get(1), null)).get(0);
            Type teraType = BazaPodataka.getTypeBy(new Type(threadInputData.idList().get(2), null)).get(0);
            ResultSet resultSet = connection.createStatement().executeQuery(
                    "SELECT * FROM TEAM_POKEMON_MOVES WHERE TEAM_POKEMON_ID = " + threadInputData.id()
            );

            List<Move> moveList = BazaPodataka.getMoveBy(null);
            boolean postoji = false;
            if (threadInputData.collection().isEmpty())
                postoji = true;
            else {
                for (Move move : threadInputData.collection()) {
                    if (moveList.stream().anyMatch(move1 -> move1.getId().equals(move.getId()))) {
                        postoji = true;
                        break;
                    }
                }
            }
            if (!postoji) return;

            Set<Move> moveSet = new HashSet<>();
            while (resultSet.next()) {
                Long moveId = resultSet.getLong("move_id");
                Move move = moveList.stream().filter(move1 -> move1.getId().equals(moveId)).findFirst().get();
                moveSet.add(move);
            }

            TeamPokemon newTeamPokemon = new TeamPokemon(Integer.toUnsignedLong(threadInputData.id()), pokemon, moveSet, ability, teraType);
            BazaPodataka.teamPokemonList.add(newTeamPokemon);
        } catch (SQLException | BazaPodatakaException e) {
            logger.error(e.getMessage(), e);
        }
    }
}
