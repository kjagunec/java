package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Type;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Generator {
    public Generator() {
    }

    public static void generateId() {
        List<String> lista = new ArrayList<>();
        try {
            lista = Files.readAllLines(Path.of("dat/abilitydex"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/abilitydex"))) {
            int i = 0;
            for (String string : lista) {
                dat.write(String.valueOf(i + 1));
                dat.newLine();
                dat.write(string);
                dat.newLine();
                i++;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void generateAttackIds(String name) {

        final int BROJ_LINIJE = 5;

        List<String> lista = new ArrayList<>();
        List<String> listaNapada = new ArrayList<>();
        try {
            lista = Files.readAllLines(Path.of("dat/pokedex"));
            listaNapada = Files.readAllLines(Path.of("dat/movedex"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/pokedex"))) {
            boolean isti = false;
            for (String entitet : lista) {
                if (entitet.equals(lista.get(lista.size() - 1))) {
                    for (int i = 0; i < listaNapada.size() / 4; i++) {
                        if (listaNapada.get(i * 4 + 1).equals(name)) {
                            isti = true;
                            dat.write(entitet + " " + listaNapada.get(i * 4));
                            System.out.println("Dodan napad " + name + " Id: " + listaNapada.get(i * 4));
                            break;
                        }
                    }
                    if(!isti) {
                        dat.write(entitet);
                        System.out.println("Nije pronađen navedeni napad!");
                    }
                }
                else
                    dat.write(entitet);
                dat.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void generateAbilityIds(String name) {
        List<String> lista = new ArrayList<>();
        List<String> listaAbility = new ArrayList<>();
        try {
            lista = Files.readAllLines(Path.of("dat/pokedex"));
            listaAbility = Files.readAllLines(Path.of("dat/abilitydex"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/pokedex"))) {
            boolean isti = false;
            for (String entitet : lista) {
                if (entitet.equals(lista.get(lista.size() - 1))) {
                    for (int i = 0; i < listaAbility.size() / 2; i++) {
                        if (listaAbility.get(i * 2 + 1).equals(name)) {
                            isti = true;
                            if (entitet.equals("pocetak"))
                                dat.write(listaAbility.get(i * 2));
                            else
                                dat.write(entitet + " " + listaAbility.get(i * 2));
                            System.out.println("Dodan nature " + name + " Id: " + listaAbility.get(i * 2));
                            break;
                        }
                    }
                    if(!isti) {
                        dat.write(entitet);
                        System.out.println("Nije pronađen navedeni nature!");
                    }
                }
                else
                    dat.write(entitet);
                dat.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void izdvojiAbilitije() {
        List<String> lista = new ArrayList<>();
        int br = 0;
        try {
            lista = Files.readAllLines(Path.of("dat/abilitydex"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/abilitydex"))) {
            for (String string : lista) {
                int i = 0;
                for (char c : string.toCharArray()) {
                    if (c < 58 && c > 47) {
                        br = i;
                        break;
                    }
                    i++;
                }
                dat.write(string.substring(0, br).trim());
                dat.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void generateTypeIds() {
        List<Type> typeList = new TypeReader().read();
        List<String> lista = new ArrayList<>();
        try {
            lista = Files.readAllLines(Path.of("dat/movedex"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/movedex"))) {
            for (int i = 0; i < lista.size() / 4; i++) {
                dat.write(lista.get(i * 4));
                dat.newLine();
                dat.write(lista.get(i * 4 + 1));
                dat.newLine();
                for (Type type : typeList) {
                    if (type.getName().equals(lista.get(i * 4 + 2))) {
                        dat.write(String.valueOf(type.getId()));
                        break;
                    }
                }
                dat.newLine();
                dat.write(lista.get(i * 4 + 3));
                dat.newLine();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void hashPass() {
        List<String> lista = new ArrayList<>();
        try {
            lista = Files.readAllLines(Path.of("dat/loginInfo"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter dat = new BufferedWriter(new FileWriter("dat/loginInfoNovi.txt"))) {
            int i = 0;
            for (String string : lista) {
                if (i == 1) {
                    dat.write(String.valueOf(string.hashCode()));
                    dat.newLine();
                    i = 0;
                }
                else {
                    dat.write(string);
                    dat.newLine();
                    i = 1;
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

