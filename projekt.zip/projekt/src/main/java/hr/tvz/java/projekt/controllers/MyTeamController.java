package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

public class MyTeamController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TableView<TeamPokemon> tableView;
    @FXML
    private TableColumn<TeamPokemon, String> pokemonTableColumn;
    @FXML
    private TableColumn<TeamPokemon, String> typesTableColumn;
    @FXML
    private TableColumn<TeamPokemon, String> movesTableColumn;
    @FXML
    private TableColumn<TeamPokemon, String> abilityTableColumn;
    @FXML
    private TableColumn<TeamPokemon, String> teraTableColumn;
    private List<TeamPokemon> teamPokemonList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            teamPokemonList = BazaPodataka.getTeamPokemonBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        pokemonTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        typesTableColumn.setCellValueFactory(cellData -> {
            Iterator<Type> iterator = cellData.getValue().getPokemon().getType().iterator();
            StringBuilder string = null;
            while (iterator.hasNext()) {
                if (string == null)
                    string = new StringBuilder(iterator.next().getName());
                else
                    string.append("\n").append(iterator.next().getName());
            }
            return new SimpleStringProperty(string.toString());
        });
        movesTableColumn.setCellValueFactory(cellData -> {
            Iterator<Move> iterator = cellData.getValue().getMoves().iterator();
            StringBuilder string = null;
            while (iterator.hasNext()) {
                if (string == null)
                    string = new StringBuilder(iterator.next().getName());
                else
                    string.append("\n").append(iterator.next().getName());
            }
            return new SimpleStringProperty(string.toString());
        });
        abilityTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getAbility().getName()));
        teraTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTeraType().getName()));
        tableView.setItems(FXCollections.observableList(teamPokemonList));
        logger.info("My Team ekran inicijaliziran.");
    }

    @FXML
    private void add() {
        String fxml = "myTeamInput.fxml";
        try {
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            stage.setTitle("Add pokemon to team");
            stage.setScene(scene);
            stage.showAndWait();
            tableView.setItems(FXCollections.observableList(BazaPodataka.getTeamPokemonBy(null)));
        }
        catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }
    }

    @FXML
    private void remove() {
        Alert alert = QuickDialog.potvrda("brisanje");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent()) {
            if (result.get() == alert.getButtonTypes().get(0)) {
                try {
                    TeamPokemon selectedTeamPokemon = tableView.getSelectionModel().getSelectedItem();
                    tableView.getItems().remove(tableView.getSelectionModel().getSelectedItem());
                    BazaPodataka.removeTeamPokemon(selectedTeamPokemon);
                    String message = "Izbrisan pokemon iz tima imena: " + selectedTeamPokemon.getName();
                    logger.info(message);
                    QuickDialog.dialogInfo(message);
                    Change<TeamPokemon> change = new Change<>(selectedTeamPokemon, LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                    change.addToDat();
                } catch (BazaPodatakaException e) {
                    BazaPodataka.bazaPodatakaAlert(e);
                }
            }
        }
    }
}
