package hr.tvz.java.projekt.entiteti;

import java.io.Serializable;

public enum MoveType implements Serializable {
    PHYSICAL(1, "physical"), SPECIAL(2, "special"), STATUS(3, "status");
    private final Integer id;
    private final String type;

    MoveType(Integer id, String type) {
        this.id = id;
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public Integer getId() {
        return id;
    }
}
