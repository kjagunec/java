package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.*;

public class MovesController implements ControllerPokedex {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField nameTextField;
    @FXML
    private ChoiceBox<Type> pokemonTypeChoiceBox;
    @FXML
    private ChoiceBox<MoveType> moveTypeChoiceBox;
    @FXML
    private Button removeButton;
    @FXML
    private TableView<Move> moveTableView;
    @FXML
    private TableColumn<Move, String> nameTableColumn;
    @FXML
    private TableColumn<Move, String> pokemonTypeTableColumn;
    @FXML
    private TableColumn<Move, String> moveTypeTableColumn;
    private List<Move> moveList = new ArrayList<>();
    private List<Type> typeList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            typeList = BazaPodataka.getTypeBy(null);
            moveList = BazaPodataka.getMoveBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        Arrays.stream(MoveType.values()).toList().forEach(moveType -> moveTypeChoiceBox.getItems().add(moveType));
        moveTypeChoiceBox.getItems().add(null);
        typeList.forEach(pokemonType -> pokemonTypeChoiceBox.getItems().add(pokemonType));
        pokemonTypeChoiceBox.getItems().add(null);

        if (LoginController.currentRole.id().equals(1L))
            removeButton.setVisible(true);
        removeButton.setTooltip(new Tooltip("Gleda se samo prema imenu"));

        nameTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        pokemonTypeTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPokemonType().getName()));
        moveTypeTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getMoveType().getType()));
        moveTableView.setItems(FXCollections.observableList(moveList));
        logger.info("Move ekran inicijaliziran.");
    }
    @FXML
    public void search() {
        List<Move> sortedList = moveList;
        if (!nameTextField.getText().isBlank())
            sortedList = sortedList
                    .stream()
                    .filter(move -> move.getName().contains(nameTextField.getText().trim()))
                    .toList();
        if (Optional.ofNullable(pokemonTypeChoiceBox.getValue()).isPresent())
            sortedList = sortedList
                    .stream()
                    .filter(move -> move.getPokemonType().getId().equals(pokemonTypeChoiceBox.getValue().getId()))
                    .toList();
        if (Optional.ofNullable(moveTypeChoiceBox.getValue()).isPresent())
            sortedList = sortedList
                    .stream()
                    .filter(move -> move.getMoveType().getId().equals(moveTypeChoiceBox.getValue().getId())).toList();

        moveTableView.setItems(FXCollections.observableList(sortedList));
        logger.info("Izvršena pretraga napada.");
    }
    @FXML
    public void add() {
        List<String> errorList = new ArrayList<>();
        if (nameTextField.getText().isBlank())
            errorList.add("Ime je obavezan podatak!");
        if (Optional.ofNullable(pokemonTypeChoiceBox.getValue()).isEmpty())
            errorList.add("Pokemon type je obavezan podatak!");
        if (Optional.ofNullable(moveTypeChoiceBox.getValue()).isEmpty())
            errorList.add("Move type je obavezan podatak!");
        if (errorList.size() == 0) {
            Alert alert = QuickDialog.potvrda("dodavanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Move inputMove = new Move(
                                null,
                                nameTextField.getText().trim(),
                                pokemonTypeChoiceBox.getValue(),
                                moveTypeChoiceBox.getValue());
                        Move newMove = BazaPodataka.addMove(inputMove);
                        moveList = BazaPodataka.getMoveBy(null);
                        moveTableView.setItems(FXCollections.observableList(moveList));
                        String message = "Dodan novi napad imena: " + nameTextField.getText().trim();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                        Change<Move> change = new Change<>(newMove, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    } catch (SameNameException e) {
                        QuickDialog.dialogWarning(e.getMessage());
                    }
                }
            }
        } else
            QuickDialog.missingInput(errorList);
    }
    @FXML
    public void remove() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("brisanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Optional<Move> optionalMove = BazaPodataka.removeMove(nameTextField.getText().trim());
                        if (optionalMove.isPresent()) {
                            moveList = BazaPodataka.getMoveBy(null);
                            moveTableView.setItems(FXCollections.observableList(moveList));
                            String message = "Izbrisan napad imena: " + optionalMove.get().getName();
                            logger.info(message);
                            QuickDialog.dialogInfo(message);
                            Change<Move> change = new Change<>(optionalMove.get(), LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                            change.addToDat();
                        }
                        else {
                            logger.warn("Pokušaj brisanja napada s imenom: " + nameTextField.getText().trim());
                            QuickDialog.dialogWarning("Ne postoji napad s imenom " + nameTextField.getText().trim());
                        }
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }

        }
    }
}
