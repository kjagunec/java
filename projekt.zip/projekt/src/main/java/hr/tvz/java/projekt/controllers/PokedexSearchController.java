package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import org.controlsfx.control.SearchableComboBox;
import org.controlsfx.control.SegmentedButton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class PokedexSearchController {

    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField pokedexNumberTextField;
    @FXML
    private SearchableComboBox<String> comboBoxName;
    @FXML
    private SearchableComboBox<String> comboBoxMove;
    @FXML
    private SearchableComboBox<String> comboBoxAbility;
    @FXML
    private TextField baseStatsTextField;
    @FXML
    private ChoiceBox<EggGroup> choiceBoxEggGroup;
    @FXML
    private ChoiceBox<Type> type1ChoiceBox;
    @FXML
    private ChoiceBox<Type> type2ChoiceBox;
    private final ToggleButton lvlUpButton = new ToggleButton("Lvl Up");
    private final ToggleButton tmButton = new ToggleButton("TM");
    private final ToggleButton eggButton = new ToggleButton("Egg");
    private final ToggleButton preEvoButton = new ToggleButton("Pre-Evo");
    private final ToggleButton reminderButton = new ToggleButton("Reminder");
    @FXML
    private SegmentedButton segmentedButton = new SegmentedButton();
    @FXML
    private ToggleButton hiddenButton;
    @FXML
    private TableView<Pokemon> pokemonTableView;
    @FXML
    private TableColumn<Pokemon, String> pokedexNumberTableColumn;
    @FXML
    private TableColumn<Pokemon, String> nameTableColumn;
    @FXML
    private TableColumn<Pokemon, String> typeTableColumn;
    @FXML
    private TableColumn<Pokemon, String> normalAbilitiesTableColumn;
    @FXML
    private TableColumn<Pokemon, String> hiddenAbilitiesTableColumn;
    @FXML
    private TableColumn<Pokemon, String> baseStatsTotalTableColumn;
    @FXML
    private TableColumn<Pokemon, String> eggGroupsTableColumn;
    /*@FXML
    private TableColumn<Pokemon, ImageView> imageViewTableColumn;*/
    public static List<Pokemon> pokemonList = Collections.synchronizedList(new ArrayList<>());
    private List<Type> typeList = new ArrayList<>();
    private List<Ability> abilityList = new ArrayList<>();
    private List<EggGroup> eggGroupList = new ArrayList<>();
    private List<Move> moveList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
           pokemonList = BazaPodataka.getPokemonBy(null);
           typeList = BazaPodataka.getTypeBy(null);
           abilityList = BazaPodataka.getAbilityBy(null);
           eggGroupList = BazaPodataka.getEggGroupBy(null);
           moveList = BazaPodataka.getMoveBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        segmentedButton.getButtons().addAll(lvlUpButton, tmButton, eggButton, preEvoButton, reminderButton);

        comboBoxName.getItems().add(null);
        pokemonList.forEach(pokemon -> comboBoxName.getItems().add(pokemon.getName()));
        comboBoxMove.getItems().add(null);
        moveList.forEach(move -> comboBoxMove.getItems().add(move.getName()));
        comboBoxAbility.getItems().add(null);
        abilityList.forEach(ability -> comboBoxAbility.getItems().add(ability.getName()));
        type1ChoiceBox.getItems().add(null);
        typeList.forEach(pokemonType -> type1ChoiceBox.getItems().add(pokemonType));
        type2ChoiceBox.getItems().add(null);
        typeList.forEach(pokemonType -> type2ChoiceBox.getItems().add(pokemonType));
        choiceBoxEggGroup.getItems().add(null);
        eggGroupList.forEach(eggGroup -> choiceBoxEggGroup.getItems().add(eggGroup));

        pokedexNumberTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPokedexNumber().toString()));
        nameTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        typeTableColumn.setCellValueFactory(cellData -> {
            Iterator<Type> iterator = cellData.getValue().getType().iterator();
            StringBuilder string = null;
            while (iterator.hasNext()) {
                if (string == null)
                    string = new StringBuilder(iterator.next().getName());
                else
                    string.append("\n").append(iterator.next().getName());
            }
            return new SimpleStringProperty(string.toString());
        });
        normalAbilitiesTableColumn.setCellValueFactory(cellData -> {
            Iterator<Ability> abilityIterator = cellData.getValue().getAllAbilities().iterator();
            StringBuilder string = null;
            while (abilityIterator.hasNext()) {
                Ability ability = abilityIterator.next();
                if (ability.getHidden())
                    hiddenAbilitiesTableColumn.setCellValueFactory(cellData2 -> new SimpleStringProperty(ability.getName()));
                else {
                    if (string == null)
                        string = new StringBuilder(ability.getName());
                    else
                        string.append("\n").append(ability.getName());
                }
            }
            return new SimpleStringProperty(string.toString());
        });
        baseStatsTotalTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(cellData.getValue().getBaseStats().baseStatsTotal())));
        eggGroupsTableColumn.setCellValueFactory(cellData -> {
            Iterator<EggGroup> iterator = cellData.getValue().getEggGroups().iterator();
            StringBuilder string = null;
            while (iterator.hasNext()) {
                if (string == null)
                    string = new StringBuilder(iterator.next().getName());
                else
                    string.append("\n").append(iterator.next().getName());
            }
            return new SimpleStringProperty(string.toString());
        });
        //imageViewTableColumn.setCellValueFactory(new PropertyValueFactory<>("imageView"));
        pokemonTableView.setItems(FXCollections.observableList(pokemonList));
        logger.info("Pokedex search ekran inicijaliziran.");
    }
    @FXML
    public void search() {
        List<Pokemon> sortiranaLista = pokemonList;
        if (!pokedexNumberTextField.getText().isBlank())
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> pokemon.getPokedexNumber().equals(Integer.parseInt(pokedexNumberTextField.getText().trim())))
                    .toList();
        if (Optional.ofNullable(comboBoxName.getValue()).isPresent()) {
            if (!comboBoxName.getValue().isBlank())
                sortiranaLista = sortiranaLista
                        .stream()
                        .filter(pokemon -> pokemon.getName().contains(comboBoxName.getValue().trim()))
                        .toList();
        }
        if (Optional.ofNullable(comboBoxMove.getValue()).isPresent()) {
            if (!comboBoxMove.getValue().isBlank()) {
                sortiranaLista = provjeriCheckBox(sortiranaLista, lvlUpButton, LearnableMovesType.LVLUP);
                sortiranaLista = provjeriCheckBox(sortiranaLista, tmButton, LearnableMovesType.TM);
                sortiranaLista = provjeriCheckBox(sortiranaLista, eggButton, LearnableMovesType.EGG);
                sortiranaLista = provjeriCheckBox(sortiranaLista, preEvoButton, LearnableMovesType.PRE_EVO);
                sortiranaLista = provjeriCheckBox(sortiranaLista, reminderButton, LearnableMovesType.REMINDER);
                if (!lvlUpButton.isSelected() && !tmButton.isSelected() && !eggButton.isSelected() &&
                        !preEvoButton.isSelected() && !reminderButton.isSelected())
                        sortiranaLista = provjeriCheckBox(sortiranaLista, null, null);
            }
        }

        if (Optional.ofNullable(comboBoxAbility.getValue()).isPresent()) {
            if (!comboBoxAbility.getValue().isBlank()) {
                if (hiddenButton.isSelected()) {
                    sortiranaLista = sortiranaLista
                            .stream()
                            .filter(pokemon -> pokemon.getAllAbilities()
                                    .stream()
                                    .anyMatch(ability -> ability.getHidden() && ability.getName().contains(comboBoxAbility.getValue().trim())))
                            .toList();
                } else {
                    sortiranaLista = sortiranaLista
                            .stream()
                            .filter(pokemon -> pokemon.getAllAbilities()
                                    .stream()
                                    .map(Ability::getName)
                                    .anyMatch(name -> name.contains(comboBoxAbility.getValue().trim())))
                            .toList();
                }
            }
        }
        if (Optional.ofNullable(type1ChoiceBox.getValue()).isPresent()) {
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> pokemon.getType()
                            .stream()
                            .anyMatch(type -> type.getId().equals(type1ChoiceBox.getValue().getId())))
                    .toList();
        }
        if (Optional.ofNullable(type2ChoiceBox.getValue()).isPresent()) {
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> pokemon.getType()
                            .stream()
                            .anyMatch(type -> type.getId().equals(type2ChoiceBox.getValue().getId())))
                    .toList();
        }
        if (!baseStatsTextField.getText().isBlank())
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> Integer.valueOf(baseStatsTextField.getText().trim())
                            .compareTo(pokemon.getBaseStats().baseStatsTotal()) < 0)
                    .toList();
        if (Optional.ofNullable(choiceBoxEggGroup.getValue()).isPresent()) {
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> pokemon.getEggGroups()
                            .stream()
                            .anyMatch(eggGroup -> eggGroup.getId().equals(choiceBoxEggGroup.getValue().getId())))
                    .toList();
        }
        logger.info("Izvršena pretraga pokemona.");
        pokemonTableView.setItems(FXCollections.observableList(sortiranaLista));
    }

    private List<Pokemon> provjeriCheckBox(List<Pokemon> sortiranaLista, ToggleButton toggleButton, LearnableMovesType type) {
        if (Optional.ofNullable(type).isEmpty()) {
            sortiranaLista = sortiranaLista
                    .stream()
                    .filter(pokemon -> pokemon.getLearnableMoves()
                            .get(LearnableMovesType.LVLUP)
                            .stream()
                            .map(Move::getName)
                            .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())) || pokemon.getLearnableMoves()
                            .get(LearnableMovesType.TM)
                            .stream()
                            .map(Move::getName)
                            .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())) || pokemon.getLearnableMoves()
                            .get(LearnableMovesType.EGG)
                            .stream()
                            .map(Move::getName)
                            .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())) || pokemon.getLearnableMoves()
                            .get(LearnableMovesType.PRE_EVO)
                            .stream()
                            .map(Move::getName)
                            .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())) || pokemon.getLearnableMoves()
                            .get(LearnableMovesType.REMINDER)
                            .stream()
                            .map(Move::getName)
                            .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())))
                    .toList();
        }
        else {
            if (toggleButton.isSelected()) {
                sortiranaLista = sortiranaLista
                        .stream()
                        .filter(pokemon -> pokemon.getLearnableMoves().get(type)
                                .stream()
                                .map(Move::getName)
                                .anyMatch(s -> s.contains(comboBoxMove.getValue().trim())))
                        .toList();
            }
        }
        return sortiranaLista;
    }
}
