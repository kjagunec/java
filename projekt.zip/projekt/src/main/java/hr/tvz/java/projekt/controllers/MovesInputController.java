package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.LearnableMovesType;
import hr.tvz.java.projekt.entiteti.Move;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.IncorrectNameException;
import hr.tvz.java.projekt.iznimke.SameEntityAlreadyInList;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.controlsfx.control.SearchableComboBox;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MovesInputController extends InputController<Move> {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private SearchableComboBox<String> lvlUpComboBox;
    @FXML
    private SearchableComboBox<String> eggComboBox;
    @FXML
    private SearchableComboBox<String> tmComboBox;
    @FXML
    private SearchableComboBox<String> preEvolutionComboBox;
    @FXML
    private SearchableComboBox<String> reminderComboBox;
    @FXML
    private TableView<Move> lvlUpTableView;
    @FXML
    private TableView<Move> eggTableView;
    @FXML
    private TableView<Move> tmTableView;
    @FXML
    private TableView<Move> preEvolutionTableView;
    @FXML
    private TableView<Move> reminderTableView;
    @FXML
    private TableColumn<Move, String> lvlUpTableColumn;
    @FXML
    private TableColumn<Move, String> eggTableColumn;
    @FXML
    private TableColumn<Move, String> tmTableColumn;
    @FXML
    private TableColumn<Move, String> preEvolutionTableColumn;
    @FXML
    private TableColumn<Move, String> reminderTableColumn;
    private List<Move> moveList = new ArrayList<>();
    private List<Move> lvlUpList = new ArrayList<>(PokedexAddController.inputMovesMap.get(LearnableMovesType.LVLUP));
    private List<Move> eggList = new ArrayList<>(PokedexAddController.inputMovesMap.get(LearnableMovesType.EGG));
    private List<Move> tmList = new ArrayList<>(PokedexAddController.inputMovesMap.get(LearnableMovesType.TM));
    private List<Move> preEvolutionList = new ArrayList<>(PokedexAddController.inputMovesMap.get(LearnableMovesType.PRE_EVO));
    private List<Move> reminderList = new ArrayList<>(PokedexAddController.inputMovesMap.get(LearnableMovesType.REMINDER));

    @FXML
    private void initialize() {
        try {
            moveList = new ArrayList<>(BazaPodataka.getMoveBy(null));
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        moveList.forEach(move -> {
            lvlUpComboBox.getItems().add(move.getName());
            eggComboBox.getItems().add(move.getName());
            tmComboBox.getItems().add(move.getName());
            preEvolutionComboBox.getItems().add(move.getName());
            reminderComboBox.getItems().add(move.getName());
        });

        eggTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        lvlUpTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        tmTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        preEvolutionTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        reminderTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));

        eggTableView.setItems(FXCollections.observableList(eggList));
        lvlUpTableView.setItems(FXCollections.observableList(lvlUpList));
        preEvolutionTableView.setItems(FXCollections.observableList(preEvolutionList));
        reminderTableView.setItems(FXCollections.observableList(reminderList));
        tmTableView.setItems(FXCollections.observableList(tmList));

        logger.info("Moves input ekran inicijaliziran.");
    }


    @FXML
    public void confirm() {
        if (tmTableView.getItems().isEmpty() && lvlUpTableView.getItems().isEmpty() && eggTableView.getItems().isEmpty() &&
                preEvolutionTableView.getItems().isEmpty() && reminderTableView.getItems().isEmpty())
            reset();
        else {
            if (!lvlUpList.isEmpty()) {
                PokedexAddController.inputMovesMap.put(LearnableMovesType.LVLUP, lvlUpList);
            }
            if (!tmList.isEmpty()) {
                PokedexAddController.inputMovesMap.put(LearnableMovesType.TM, tmList);
            }
            if (!eggList.isEmpty()) {
                PokedexAddController.inputMovesMap.put(LearnableMovesType.EGG, eggList);
            }
            if (!reminderList.isEmpty()) {
                PokedexAddController.inputMovesMap.put(LearnableMovesType.PRE_EVO, preEvolutionList);
            }
            if (!lvlUpList.isEmpty()) {
                PokedexAddController.inputMovesMap.put(LearnableMovesType.REMINDER, reminderList);
            }
            logger.info("Spremljen popis upisanih napada.");
        }
        backToPokedex();
    }

    @FXML
    public void backToPokedex() {
        Stage stage = (Stage) lvlUpComboBox.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void reset() {
        if (!tmTableView.getItems().isEmpty())
            tmTableView.getItems().clear();
        if (!lvlUpTableView.getItems().isEmpty())
            lvlUpTableView.getItems().clear();
        if (!reminderTableView.getItems().isEmpty())
            reminderTableView.getItems().clear();
        if (!eggTableView.getItems().isEmpty())
            eggTableView.getItems().clear();
        if (!preEvolutionTableView.getItems().isEmpty())
            preEvolutionTableView.getItems().clear();
        Arrays.stream(LearnableMovesType.values()).forEach(learnableMoveType -> PokedexAddController.inputMovesMap.get(learnableMoveType).clear());
        logger.info("Brisanje upisanih napada.");
    }

    private void addMove(SearchableComboBox<String> comboBox, TableView<Move> tableView) throws SameEntityAlreadyInList, IncorrectNameException {
        if (Optional.ofNullable(comboBox.getValue()).isPresent()) {
            try {
                Optional<Move> optionalMove = BazaPodataka.getMoveBy(new Move(null, comboBox.getValue().trim()))
                        .stream()
                        .filter(move -> move.getName().equals(comboBox.getValue().trim()))
                        .findFirst();
                if (optionalMove.isPresent()) {
                    if (tableView.getItems().stream().anyMatch(move -> move.getId().equals(optionalMove.get().getId()))) {
                        logger.warn("Pokušaj dodavanja napada koji je već dodan.");
                        throw new SameEntityAlreadyInList("Pokemon ne može imati dva ista napada!");
                    } else {
                        tableView.getItems().add(optionalMove.get());
                        logger.info("Dodan napad " + optionalMove.get().getName() + " na popis.");
                    }
                } else {
                    logger.warn("Pokušaj dodavanja napada koji ne postoji.");
                    throw new IncorrectNameException("Napad s imenom " + comboBox.getValue().trim() + " ne postoji!");
                }
            } catch (BazaPodatakaException e) {
                BazaPodataka.bazaPodatakaAlert(e);
            }
        } else
            logger.warn("Input za napad je prazan.");
    }

    @FXML
    private void addLvlUpMove() {
        try {
            addMove(lvlUpComboBox, lvlUpTableView);
        } catch (IncorrectNameException | SameEntityAlreadyInList e) {
            QuickDialog.dialogError(e.getMessage());
        }
    }
    @FXML
    private void addTmMove() {
        try {
            addMove(tmComboBox, tmTableView);
        } catch (IncorrectNameException | SameEntityAlreadyInList e) {
            QuickDialog.dialogError(e.getMessage());
        }
    }
    @FXML
    private void addEggMove() {
        try {
            addMove(eggComboBox, eggTableView);
        } catch (IncorrectNameException | SameEntityAlreadyInList e) {
            QuickDialog.dialogError(e.getMessage());
        }
    }
    @FXML
    private void addPreEvolutionMove() {
        try {
            addMove(preEvolutionComboBox, preEvolutionTableView);
        } catch (IncorrectNameException | SameEntityAlreadyInList e) {
            QuickDialog.dialogError(e.getMessage());
        }
    }
    @FXML
    private void addReminderMove() {
        try {
            addMove(reminderComboBox, reminderTableView);
        } catch (IncorrectNameException | SameEntityAlreadyInList e) {
            QuickDialog.dialogError(e.getMessage());
        }
    }

    private void clickTable(TableView<Move> tableView) {
        Alert alert = QuickDialog.potvrda("brisanje");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent()) {
            if (result.get() == alert.getButtonTypes().get(0)) {
                tableView.getItems().remove(tableView.getSelectionModel().getSelectedItem());
            }
        }
    }
    @FXML
    private void lvlUpClickTable() {
        clickTable(lvlUpTableView);
    }
    @FXML
    private void tmClickTable() {
        clickTable(tmTableView);
    }
    @FXML
    private void eggClickTable() {
        clickTable(eggTableView);
    }
    @FXML
    private void reminderClickTable() {
        clickTable(reminderTableView);
    }
    @FXML
    private void preEvolutionClickTable() {
        clickTable(preEvolutionTableView);
    }


}
