package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.EggGroup;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class EggReader extends DatReader<List<EggGroup>>{

    private static final int BROJ_ENTITETA = 2;

    public List<EggGroup> read() {
        List<EggGroup> list = new ArrayList<>();
        /*try {
            Files.readAllLines(Path.of("dat/types.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
        try (BufferedReader eggDat = new BufferedReader(new FileReader("dat/eggGroups"))) {

            System.out.println("Učitavanje egg groups...");

            List<String> stringList = eggDat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                Long id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                String name = stringList.get(i * BROJ_ENTITETA + 1);
                list.add(new EggGroup(id, name));
            }
        } catch (IOException ex) {
            System.err.println("Pogreška kod čitanja datoteke eggGroups");
        }
        return list;
    }
}
