package hr.tvz.java.projekt.entiteti;

public enum ChangeType {
    ADD, REMOVE;
}
