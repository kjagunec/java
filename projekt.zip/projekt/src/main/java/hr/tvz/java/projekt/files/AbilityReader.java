package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Ability;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AbilityReader extends DatReader<List<Ability>>{

    private static final int BROJ_ENTITETA = 2;

    public List<Ability> read() {
        List<Ability> list = new ArrayList<>();
        /*try {
            Files.readAllLines(Path.of("dat/types.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
        try (BufferedReader abilityDat = new BufferedReader(new FileReader("dat/abilitydex"))) {

            System.out.println("Učitavanje ability...");

            List<String> stringList = abilityDat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                Long id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                String name = stringList.get(i * BROJ_ENTITETA + 1);
                list.add(new Ability(id, name));
            }
        } catch (IOException ex) {
            System.err.println("Pogreška kod čitanja datoteke abilitydex");
        }
        return list;
    }
}
