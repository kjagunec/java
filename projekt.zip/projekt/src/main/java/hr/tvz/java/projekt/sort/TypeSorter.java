package hr.tvz.java.projekt.sort;

import hr.tvz.java.projekt.entiteti.Type;

import java.util.Comparator;

public class TypeSorter implements Comparator<Type> {

    @Override
    public int compare(Type o1, Type o2) {
        return Integer.compare(o1.getName().compareTo(o2.getName()), 0);
    }
}