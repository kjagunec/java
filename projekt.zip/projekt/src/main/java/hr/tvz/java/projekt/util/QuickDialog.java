package hr.tvz.java.projekt.util;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;

import java.util.List;

public class QuickDialog {
    public static void dialogWarning(String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(content);

        alert.showAndWait();
    }
    public static void dialogError(String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(content);

        alert.showAndWait();
    }
    public static void dialogInfo(String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(content);

        alert.showAndWait();
    }
    public static void missingInput(List<String> errorList) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Pogrešan unos podataka");
        alert.setHeaderText("Molimo ispravite sljedeće pogreške:");
        StringBuilder stringBuilder = new StringBuilder();
        for (String string : errorList)
            stringBuilder.append(string).append("\n");
        alert.setContentText(stringBuilder.toString());

        alert.showAndWait();
    }
    public static Alert potvrda(String string) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Potvrdite " + string + "!");

        ButtonType buttonTypeOne = new ButtonType("Da");
        ButtonType buttonTypeCancel = new ButtonType("Otkaži", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeCancel);

        return alert;
    }
}
