package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.entiteti.ChangeType;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.Ability;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AbilitiesController implements ControllerPokedex {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField nameTextField;
    @FXML
    private TableView<Ability> abilityTableView;
    @FXML
    private TableColumn<Ability, String> nameTableColumn;
    @FXML
    private Button remove;
    private List<Ability> abilityList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            abilityList = BazaPodataka.getAbilityBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        if (LoginController.currentRole.id().equals(1L))
            remove.setVisible(true);

        nameTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        abilityTableView.setItems(FXCollections.observableList(abilityList));
        logger.info("Ability ekran inicijaliziran.");
    }
    @FXML
    public void search() {
        List<Ability> sortedList = abilityList;
        if (!nameTextField.getText().isBlank()) {
            sortedList = sortedList
                    .stream()
                    .filter(ability -> ability.getName().contains(nameTextField.getText().trim()))
                    .toList();
            logger.info("Izvršena pretraga ability s imenom: " + nameTextField.getText().trim());
        } else
            logger.info("Izvršena pretraga ability.");
        abilityTableView.setItems(FXCollections.observableList(sortedList));
    }
    @FXML
    public void add() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("dodavanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Ability newAbility = BazaPodataka.addAbility(nameTextField.getText().trim());
                        abilityList = BazaPodataka.getAbilityBy(null);
                        abilityTableView.setItems(FXCollections.observableList(abilityList));
                        String message = "Dodan novi ability imena: " + nameTextField.getText().trim();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                        Change<Ability> change = new Change<>(newAbility, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    } catch (SameNameException e) {
                        QuickDialog.dialogWarning(e.getMessage());
                    }
                }
            }
        }
    }
    @FXML
    public void remove() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("brisanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Optional<Ability> optionalAbility = BazaPodataka.removeAbility(nameTextField.getText().trim());
                        if (optionalAbility.isPresent()) {
                            abilityList = BazaPodataka.getAbilityBy(null);
                            abilityTableView.setItems(FXCollections.observableList(abilityList));
                            String message = "Izbrisan ability imena: " + optionalAbility.get().getName();
                            logger.info(message);
                            QuickDialog.dialogInfo(message);
                            Change<Ability> change = new Change<>(optionalAbility.get(), LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                            change.addToDat();
                        }
                        else {
                            logger.warn("Pokušaj brisanja ability s imenom: " + nameTextField.getText().trim());
                            QuickDialog.dialogWarning("Ne postoji ability s imenom " + nameTextField.getText().trim());
                        }
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }
        }
    }
}
