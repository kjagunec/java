package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.entiteti.Entitet;

public abstract non-sealed class InputController<T extends Entitet> implements InputControllers {
}
