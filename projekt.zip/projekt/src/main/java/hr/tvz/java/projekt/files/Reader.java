package hr.tvz.java.projekt.files;

public sealed interface Reader<T> permits DatReader {
    public T read();
}
