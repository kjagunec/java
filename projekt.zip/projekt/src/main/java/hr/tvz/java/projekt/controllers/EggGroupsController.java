package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.ChangeType;
import hr.tvz.java.projekt.entiteti.EggGroup;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EggGroupsController implements ControllerPokedex {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private TextField nameTextField;
    @FXML
    private TableView<EggGroup> eggGroupTableView;
    @FXML
    private TableColumn<EggGroup, String> nameTableColumn;
    @FXML
    private Button remove;
    private List<EggGroup> eggGroupList = new ArrayList<>();

    @FXML
    private void initialize() {
        try {
            eggGroupList = BazaPodataka.getEggGroupBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        if (LoginController.currentRole.id().equals(1L))
            remove.setVisible(true);

        nameTableColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        eggGroupTableView.setItems(FXCollections.observableList(eggGroupList));
        logger.info("Egg groups ekran inicijaliziran.");
    }
    @FXML
    public void search() {
        List<EggGroup> sortedList = eggGroupList;
        if (!nameTextField.getText().isBlank()) {
            sortedList = sortedList
                    .stream()
                    .filter(eggGroup -> eggGroup.getName().contains(nameTextField.getText().trim()))
                    .toList();
            logger.info("Izvršena pretraga egg group s imenom: " + nameTextField.getText().trim());
        } else
            logger.info("Izvršena pretraga egg group.");
        eggGroupTableView.setItems(FXCollections.observableList(sortedList));
    }
    @FXML
    public void add() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("dodavanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        EggGroup newEggGroup = BazaPodataka.addEggGroup(nameTextField.getText().trim());
                        eggGroupList = BazaPodataka.getEggGroupBy(null);
                        eggGroupTableView.setItems(FXCollections.observableList(eggGroupList));
                        String message = "Dodan novi egg group imena: " + nameTextField.getText().trim();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                        Change<EggGroup> change = new Change<>(newEggGroup, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    } catch (SameNameException e) {
                        QuickDialog.dialogWarning(e.getMessage());
                    }
                }
            }
        }
    }
    @FXML
    public void remove() {
        if (!nameTextField.getText().isBlank()) {
            Alert alert = QuickDialog.potvrda("brisanje");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)){
                    try {
                        Optional<EggGroup> optionalEggGroup = BazaPodataka.removeEggGroup(nameTextField.getText().trim());
                        if (optionalEggGroup.isPresent()) {
                            eggGroupList = BazaPodataka.getEggGroupBy(null);
                            eggGroupTableView.setItems(FXCollections.observableList(eggGroupList));
                            String message = "Izbrisan egg group imena: " + optionalEggGroup.get().getName();
                            logger.info(message);
                            QuickDialog.dialogInfo(message);
                            Change<EggGroup> change = new Change<>(optionalEggGroup.get(), LoginController.currentRole, LocalDateTime.now(), ChangeType.REMOVE);
                            change.addToDat();
                        }
                        else {
                            logger.warn("Pokušaj brisanja egg group s imenom: " + nameTextField.getText().trim());
                            QuickDialog.dialogWarning("Ne postoji egg group s imenom " + nameTextField.getText().trim());
                        }
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    }
                }
            }
        }
    }
}
