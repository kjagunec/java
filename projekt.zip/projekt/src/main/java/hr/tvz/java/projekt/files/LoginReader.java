package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Role;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LoginReader extends DatReader<List<Role>>{

    private static final int BROJ_ENTITETA = 3;

    public List<Role> read() {
        List<Role> lista = new ArrayList<>();
        try (BufferedReader dat = new BufferedReader(new FileReader("dat/loginInfo"))) {

            List<String> stringList = dat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                Long id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                String ime = stringList.get(i * BROJ_ENTITETA + 1);
                Integer lozinkaHash = Integer.parseInt(stringList.get(i * BROJ_ENTITETA + 2));
                lista.add(new Role(id, ime, lozinkaHash));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lista;
    }

}
