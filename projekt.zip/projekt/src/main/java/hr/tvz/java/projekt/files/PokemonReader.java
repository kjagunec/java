package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class PokemonReader extends DatReader<List<Pokemon>>{

    private static final int BROJ_ENTITETA = 13;

    public List<Pokemon> read() {
        Set<Pokemon> set = new HashSet<>();
        /*try {
            Files.readAllLines(Path.of("dat/types.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
        Long id = null;
        String name = null;
        Set<Type> types = new HashSet<>();
        Map<LearnableMovesType, Set<Move>> learnableMoves = new HashMap<>();
        Set<Ability> abilities = new HashSet<>();
        BaseStats baseStats = null;
        Set<EggGroup> eggGroups = new HashSet<>();
        List<Pokemon> pokemonList = new ArrayList<>();
        try (BufferedReader pokedexDat = new BufferedReader(new FileReader("dat/pokedex"))) {

            System.out.println("Učitavanje pokemona...");

            List<Type> typeList = new TypeReader().read();
            List<Ability> abilityList = new AbilityReader().read();
            List<EggGroup> eggGroupList = new EggReader().read();
            List<String> stringList = pokedexDat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                Integer pokedexNumber = Integer.parseInt(stringList.get(i * BROJ_ENTITETA + 1));
                name = stringList.get(i * BROJ_ENTITETA + 2);
                List<Long> typeListId = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 3));
                List<Long> lvlUpList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 4));
                List<Long> tmList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 5));
                List<Long> eggMovesList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 6));
                List<Long> preEvolutionList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 7));
                List<Long> reminderList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 8));
                List<Long> abilityListId = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 9));
                long hiddenAbilityId = Long.parseLong(stringList.get(i * BROJ_ENTITETA + 10));
                List<Long> statsList = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 11));
                List<Long> eggGroupListId = izdvojiBrojeveIzStringa(stringList.get(i * BROJ_ENTITETA + 12));

                for (Long typeId : typeListId) {
                    for (Type type : typeList) {
                        if (type.getId().equals(typeId)) {   //else throw exception
                            types.add(type);
                            break;
                        }
                    }
                }

                learnableMoves.put(LearnableMovesType.LVLUP, dodajNapadeUMapu(lvlUpList));
                learnableMoves.put(LearnableMovesType.TM, dodajNapadeUMapu(tmList));
                learnableMoves.put(LearnableMovesType.EGG, dodajNapadeUMapu(eggMovesList));
                learnableMoves.put(LearnableMovesType.PRE_EVO, dodajNapadeUMapu(preEvolutionList));
                learnableMoves.put(LearnableMovesType.REMINDER, dodajNapadeUMapu(reminderList));

                for (Long abilityId : abilityListId) {
                    for (Ability ability : abilityList) {
                        if (ability.getId().equals(abilityId)) {   //else throw exception
                            abilities.add(ability);
                            break;
                        }
                    }
                }
                for (Ability ability : abilityList) {
                    if (ability.getId().equals(hiddenAbilityId)) {  //else throw exception
                        ability.setHidden(true);
                        abilities.add(ability);
                        break;
                    }
                }

                Iterator<Long> iterator = statsList.iterator();
                baseStats = new BaseStats(Math.toIntExact(iterator.next()), Math.toIntExact(iterator.next()), Math.toIntExact(iterator.next()), Math.toIntExact(iterator.next()), Math.toIntExact(iterator.next()), Math.toIntExact(iterator.next()));

                for (Long eggId : eggGroupListId) {
                    for (EggGroup eggGroup : eggGroupList) {
                        if (eggGroup.getId().equals(eggId)) {   //else throw exception
                            eggGroups.add(eggGroup);
                            break;
                        }
                    }
                }

                pokemonList.add(new Pokemon.Builder(id, name)
                        .setPokedexNumber(pokedexNumber)
                        .setType(types)
                        .setLearnableMoves(learnableMoves)
                        .setAllAbilities(abilities)
                        .setBaseStats(baseStats)
                        .setEggGroups(eggGroups)
                        .build());
            }
        } catch (IOException ex) {
            System.err.println("Pogreška kod čitanja datoteke pokedex");
        }
        return pokemonList;
    }
    public static List<Long> izdvojiBrojeveIzStringa(String string) {
        List<Long> listaBrojeva = new ArrayList<>();
        int i = 0, pocetak = 0, kraj;

        for (char c : string.toCharArray()) {
            if (c == ' ') {
                kraj = i;
                listaBrojeva.add(Long.parseLong(string.substring(pocetak, kraj)));
                pocetak = kraj + 1;
            }
            i++;
        }

        listaBrojeva.add(Long.parseLong(string.substring(pocetak)));

        return listaBrojeva;
    }

    private Set<Move> dodajNapadeUMapu(List<Long> lista){
        Set<Move> moves = new HashSet<>();
        List<Move> moveList = new MoveReader().read();

        if (lista.get(0).equals(0L))    //exception?
            return moves;
        for (Long id : lista) {
            for (Move move : moveList) {
                if (move.getId().equals(id)) {   //else throw exception
                    moves.add(move);
                    break;
                }
            }
        }
        return moves;
    }
}
