package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Move;
import hr.tvz.java.projekt.entiteti.MoveType;
import hr.tvz.java.projekt.entiteti.Type;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MoveReader extends DatReader<List<Move>> {

    private static final int BROJ_ENTITETA = 4;

    public List<Move> read() {
        List<Move> list = new ArrayList<>();
        /*try {
            Files.readAllLines(Path.of("dat/types.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
        try (BufferedReader moveDat = new BufferedReader(new FileReader("dat/movedex"))) {

            System.out.println("Učitavanje napada...");

            List<Type> typeList = new TypeReader().read();
            List<String> stringList = moveDat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                Long id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                String name = stringList.get(i * BROJ_ENTITETA + 1);
                Long typeId = Long.parseLong(stringList.get(i * BROJ_ENTITETA + 2));
                String moveTypeString = stringList.get(i * BROJ_ENTITETA + 3);

                Type pokemonType = null;
                boolean postoji = false;
                for (Type type : typeList) {
                    if (type.getId().equals(typeId)) {
                        pokemonType = type;
                        postoji = true;
                        break;
                    }
                }
                if(!postoji) {
                    System.out.println();
                    throw new RuntimeException("Nije pronađen navedeni tip s ID: " + typeId);
                }
                list.add(new Move(id, name, pokemonType, MoveType.valueOf(moveTypeString.toUpperCase())));
            }
        } catch (IOException ex) {
            System.err.println("Pogreška kod čitanja datoteke movedex");
        }
        return list;
    }
}