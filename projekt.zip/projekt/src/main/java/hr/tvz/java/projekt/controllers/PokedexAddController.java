package hr.tvz.java.projekt.controllers;

import hr.tvz.java.projekt.baza.BazaPodataka;
import hr.tvz.java.projekt.entiteti.*;
import hr.tvz.java.projekt.iznimke.BazaPodatakaException;
import hr.tvz.java.projekt.iznimke.SameNameException;
import hr.tvz.java.projekt.main.LoginScreen;
import hr.tvz.java.projekt.util.Change;
import hr.tvz.java.projekt.util.QuickDialog;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

public class PokedexAddController {
    private static final Logger logger = LoggerFactory.getLogger(LoginScreen.class);
    @FXML
    private Label title;
    @FXML
    private TextField numberTextField;
    @FXML
    private TextField nameTextField;
    @FXML
    private Label abilityCheck;
    @FXML
    private Label movesCheck;
    @FXML
    private Label eggGroupCheck;
    @FXML
    private Label baseStatsCheck;
    @FXML
    private ChoiceBox<Type> type1ChoiceBox;
    @FXML
    private ChoiceBox<Type> type2ChoiceBox;
    private List<Type> typeList = new ArrayList<>();
    static Map<LearnableMovesType, List<Move>> inputMovesMap = new HashMap<>();
    static List<Ability> inputAbilityList = new ArrayList<>();
    static List<EggGroup> inputEggGroupList = new ArrayList<>();
    static BaseStats baseStats;
    private boolean movesInput;

    @FXML
    private void initialize() {
        Arrays.stream(LearnableMovesType.values()).forEach(learnableMoveType -> inputMovesMap.put(learnableMoveType, new ArrayList<>()));
        try {
            typeList = BazaPodataka.getTypeBy(null);
        } catch (BazaPodatakaException e) {
            BazaPodataka.bazaPodatakaAlert(e);
        }

        typeList.forEach(pokemonType -> type2ChoiceBox.getItems().add(pokemonType));
        type2ChoiceBox.getItems().add(null);
        typeList.forEach(pokemonType -> type1ChoiceBox.getItems().add(pokemonType));
        type1ChoiceBox.getItems().add(null);
        logger.info("Pokedex add ekran inicijaliziran.");
    }

    @FXML
    private void showEggGroupsInput() {
        String fxml = "eggGroupsInput.fxml";
        try {
            addStage(fxml, "Input egg groups");
            eggGroupCheck.setVisible(!inputEggGroupList.isEmpty());
        }
        catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    private void showAbilitiesInput() {
        String fxml = "abilitiesInput.fxml";
        try {
            addStage(fxml, "Input abilities");
            abilityCheck.setVisible(!inputAbilityList.isEmpty());
        }
        catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    private void showMovesInput() {
        String fxml = "movesInput.fxml";
        try {
            addStage(fxml, "Input moves");
            movesInput = false;
            for (LearnableMovesType type : LearnableMovesType.values()) {
                if (!inputMovesMap.get(type).isEmpty()) {
                    movesInput = true;
                    break;
                }
            }
            movesCheck.setVisible(movesInput);
        }
        catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }
    @FXML
    private void showBaseStatsInput() {
        String fxml = "baseStatsInput.fxml";
        try {
            addStage(fxml, "Input base stats");
            baseStatsCheck.setVisible(Optional.ofNullable(baseStats).isPresent());
        }
        catch (IOException e) {
            String error = "Neuspješno otvaranje datoteke " + fxml;
            logger.error(error, e);
            QuickDialog.dialogError(error);
        }
    }

    @FXML
    private void add() {
        List<String> errorList = new ArrayList<>();
        if (numberTextField.getText().isBlank())
            errorList.add("Pokedex number je obavezan podatak!");
        if (nameTextField.getText().isBlank())
            errorList.add("Name je obavezan podatak!");
        if (Optional.ofNullable(type1ChoiceBox.getValue()).isEmpty() && Optional.ofNullable(type2ChoiceBox.getValue()).isEmpty())
            errorList.add("Pokemon type je obavezan podatak!");
        if (inputAbilityList.isEmpty())
            errorList.add("Abilities je obavezan podatak!");
        if (Optional.ofNullable(baseStats).isEmpty())
            errorList.add("Base stats je obavezan podatak!");
        if (inputEggGroupList.isEmpty())
            errorList.add("Egg groups je obavezan podatak!");
        if (!movesInput)
            errorList.add("Moves je obavezan podatak!");
        if (errorList.size() == 0) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Potvrdite dodavanje!");

            ButtonType buttonTypeOne = new ButtonType("Da");
            ButtonType buttonTypeCancel = new ButtonType("Otkaži", ButtonBar.ButtonData.CANCEL_CLOSE);

            alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeCancel);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent()) {
                if (result.get() == alert.getButtonTypes().get(0)) {
                    try {
                        Set<Type> typeSet = new HashSet<>();
                        if (Optional.ofNullable(type1ChoiceBox.getValue()).isPresent())
                            typeSet.add(type1ChoiceBox.getValue());
                        if (Optional.ofNullable(type2ChoiceBox.getValue()).isPresent())
                            typeSet.add(type2ChoiceBox.getValue());

                        Map<LearnableMovesType, Set<Move>> map = new HashMap<>();
                        Arrays.stream(LearnableMovesType.values()).forEach(learnableMoveType ->
                                map.put(learnableMoveType, new HashSet<>(inputMovesMap.get(learnableMoveType))));

                        Pokemon inputPokemon = new Pokemon.Builder(null, nameTextField.getText().trim())
                                .setPokedexNumber(Integer.parseInt(numberTextField.getText().trim()))
                                .setAllAbilities(new HashSet<>(inputAbilityList))
                                .setBaseStats(baseStats)
                                .setType(typeSet)
                                .setLearnableMoves(map)
                                .setEggGroups(new HashSet<>(inputEggGroupList))
                                .build();
                        Pokemon newPokemon = BazaPodataka.addPokemon(inputPokemon);
                        Change<Pokemon> change = new Change<>(newPokemon, LoginController.currentRole, LocalDateTime.now(), ChangeType.ADD);
                        change.addToDat();
                        String message = "Dodan novi pokemon imena: " + nameTextField.getText().trim();
                        logger.info(message);
                        QuickDialog.dialogInfo(message);
                    } catch (BazaPodatakaException e) {
                        BazaPodataka.bazaPodatakaAlert(e);
                    } catch (SameNameException e) {
                        QuickDialog.dialogWarning(e.getMessage());
                    }
                }
            }
        } else
            QuickDialog.missingInput(errorList);
    }

    private void addStage(String fxml, String title) throws IOException {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxml));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        scene.getStylesheets().add(LoginScreen.class.getResource("stylesheets.css").toString());
        stage.setTitle(title);
        stage.getIcons().add(new Image(LoginScreen.class.getResource("logo.jpg").toString()));
        stage.setScene(scene);
        stage.showAndWait();
    }
}
