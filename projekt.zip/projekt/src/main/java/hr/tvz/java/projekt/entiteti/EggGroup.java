package hr.tvz.java.projekt.entiteti;

public class EggGroup extends Entitet{

    public EggGroup(Long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return getName();
    }
}
