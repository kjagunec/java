package hr.tvz.java.projekt.entiteti;

import java.io.Serializable;

public enum LearnableMovesType implements Serializable {
    LVLUP(1, "move learnt by level up"), TM(2, "move learnable by TM"), EGG(3, "move learnable by breeding"), PRE_EVO(4, "pre-evolution only moves"), REMINDER(5, "moves learnable by move reminder");

    private final String learnaleMoves;
    private final Integer id;

    LearnableMovesType(Integer id, String learnaleMoves) {
        this.id = id;
        this.learnaleMoves = learnaleMoves;
    }

    public String getLearnaleMoves() {
        return learnaleMoves;
    }

    public Integer getId() {
        return id;
    }
}
