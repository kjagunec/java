package hr.tvz.java.projekt.files;

import hr.tvz.java.projekt.entiteti.Type;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TypeReader extends DatReader<List<Type>>{

    private static final int BROJ_ENTITETA = 2;

    public List<Type> read() {
        List<Type> list = new ArrayList<>();
        /*try {
            Files.readAllLines(Path.of("dat/types.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }*/
        try (BufferedReader typeDat = new BufferedReader(new FileReader("dat/types"))) {

            System.out.println("Učitavanje tipova...");

            List<String> stringList = typeDat.lines().toList();

            for (int i = 0; i < stringList.size() / BROJ_ENTITETA; i++) {
                Long id = Long.parseLong(stringList.get(i * BROJ_ENTITETA));
                String name = stringList.get(i * BROJ_ENTITETA + 1);
                list.add(new Type(id, name));
            }
        } catch (IOException ex) {
            System.err.println("Pogreška kod čitanja datoteke types.txt");
        }
        return list;
    }
}
