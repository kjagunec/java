module hr.tvz.java.projekt {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.slf4j;
    requires java.sql;
    requires org.controlsfx.controls;


    exports hr.tvz.java.projekt.util;
    opens hr.tvz.java.projekt.util to javafx.fxml;
    exports hr.tvz.java.projekt.controllers;
    opens hr.tvz.java.projekt.controllers to javafx.fxml;
    exports hr.tvz.java.projekt.main;
    opens hr.tvz.java.projekt.main to javafx.fxml;
    /*exports hr.tvz.java.projekt.main;
    opens hr.tvz.java.projekt.main to javafx.fxml;
    exports hr.tvz.java.projekt.entiteti;
    exports hr.tvz.java.projekt.baza;
    opens hr.tvz.java.projekt.baza to javafx.fxml;
    //opens hr.tvz.java.projekt.entiteti to javafx.fxml;*/
}